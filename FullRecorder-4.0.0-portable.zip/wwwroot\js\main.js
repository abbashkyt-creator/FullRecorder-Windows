// FullRecorder window: theme, navigation and shared state for the pages.
import { setTheme, webLightTheme, webDarkTheme } from '../vendor/fluent.js';
import { call, on, isMock } from './bridge.js';
import { hydrateIcons, formatClock, toast } from './dom.js';
import * as recordPage from './pages/record.js';
import * as recordingsPage from './pages/recordings.js';
import * as settingsPage from './pages/settings.js';
import * as aboutPage from './pages/about.js';
import * as editor from './pages/editor.js';

const PAGES = {
  record: { module: recordPage, title: 'Record' },
  recordings: { module: recordingsPage, title: 'Recordings' },
  settings: { module: settingsPage, title: 'Settings' },
  about: { module: aboutPage, title: 'About' },
};

// ---------------------------------------------------------------- theme (follows Windows / the app setting)
const darkQuery = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const dark = darkQuery.matches;
  setTheme(dark ? webDarkTheme : webLightTheme);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}
darkQuery.addEventListener('change', applyTheme);
applyTheme();

// ---------------------------------------------------------------- shared state
const subscribers = new Map();
const ctx = {
  state: { settings: {}, recordingKeys: [], status: { state: 'idle' }, startup: false, version: '', hotkeyErrors: {}, replay: { state: 'off' } },
  call,
  /** topic: 'settings' | 'status' | 'recordings' | 'hotkeys' | 'replay' */
  subscribe(topic, fn) {
    if (!subscribers.has(topic)) subscribers.set(topic, new Set());
    subscribers.get(topic).add(fn);
  },
  publish(topic) {
    for (const fn of subscribers.get(topic) ?? []) {
      try { fn(ctx.state); } catch (err) { console.error(err); }
    }
  },
  /** Saves one setting; on success updates every page, on failure throws (message is user-readable). */
  async setSetting(key, value) {
    const { values } = await call('settings.set', { key, value });
    ctx.state.settings = values;
    ctx.publish('settings');
    return values;
  },
  isRecording() { return ['starting', 'recording', 'pausing', 'paused', 'resuming', 'stopping'].includes(ctx.state.status.state); },
  /** Opens the trim / GIF dialog for a recording (set up once the pages exist). */
  openEditor: () => {},
  go(page) { if (location.hash !== `#${page}`) location.hash = page; else show(page, false); },
};

// ---------------------------------------------------------------- navigation
const nav = document.getElementById('nav');
let current = null;
let ready = false;

function pageFromHash() {
  const p = decodeURIComponent(location.hash.slice(1));
  return PAGES[p] ? p : 'record';
}

function show(page, moveFocus) {
  if (!PAGES[page]) page = 'record';
  for (const [name, def] of Object.entries(PAGES)) {
    const section = document.getElementById(`page-${name}`);
    const active = name === page;
    if (section.hidden === active) {
      section.hidden = !active;
      if (active) def.module.shown?.(ctx);
      else if (current === name) def.module.hidden?.(ctx);
    }
  }
  current = page;
  if (nav.activeid !== `tab-${page}`) nav.activeid = `tab-${page}`;
  document.title = `${PAGES[page].title} - FullRecorder`;
  if (moveFocus) document.querySelector(`#page-${page} h1`)?.focus({ preventScroll: true });
  document.getElementById('content').scrollTop = 0;
}

nav.addEventListener('change', () => {
  if (!ready) return; // the tablist reports its initial selection before the pages exist
  const tab = nav.querySelector(`#${CSS.escape(nav.activeid ?? '')}`);
  const page = tab?.dataset.page;
  if (page && page !== current) ctx.go(page);
});
addEventListener('hashchange', () => { if (ready) show(pageFromHash(), true); });

// ---------------------------------------------------------------- status in the navigation rail
const railStatus = document.getElementById('rail-status');
let lastAnnounced = '';
function renderRailStatus() {
  const s = ctx.state.status;
  const text = {
    starting: 'Starting…',
    recording: `Recording ${formatClock(s.elapsedSeconds)}`,
    pausing: 'Pausing…',
    paused: `Paused ${formatClock(s.elapsedSeconds)}`,
    resuming: 'Resuming…',
    stopping: 'Saving…',
  }[s.state] ?? 'Ready';
  railStatus.dataset.state = s.state;
  const textEl = railStatus.querySelector('.status-text');
  // Screen readers hear state changes, not every second of the timer.
  const announce = s.state === 'recording' ? 'Recording' : s.state === 'paused' ? 'Paused' : text;
  if (announce !== lastAnnounced) {
    lastAnnounced = announce;
    railStatus.setAttribute('aria-live', 'polite');
  } else {
    railStatus.setAttribute('aria-live', 'off');
  }
  textEl.textContent = text;
}

// ---------------------------------------------------------------- app events
on('status', (status) => {
  ctx.state.status = status;
  renderRailStatus();
  ctx.publish('status');
});
on('recordings', () => ctx.publish('recordings'));
on('saved', ({ path, notes }) => {
  const name = path.split(/[\\/]/).pop();
  toast(`Saved ${name}`, 'success');
  for (const n of notes ?? []) toast(n, 'warning', 10000);
  ctx.publish('recordings');
});
on('problem', ({ message }) => toast(message, 'error', 10000));
on('notice', ({ message }) => toast(message, 'info', 8000));
on('settings', (values) => { ctx.state.settings = values; ctx.publish('settings'); });
on('hotkeys', (errors) => { ctx.state.hotkeyErrors = errors ?? {}; ctx.publish('hotkeys'); });
on('replay', (status) => { ctx.state.replay = status; ctx.publish('replay'); });
on('navigate', (page) => ctx.go(page));

// ---------------------------------------------------------------- start
async function start() {
  await customElements.whenDefined('fluent-tablist');
  hydrateIcons();
  try {
    Object.assign(ctx.state, await call('app.init'));
  } catch (err) {
    document.getElementById('boot').textContent = `FullRecorder could not load its settings: ${err.message}`;
    return;
  }
  for (const [name, def] of Object.entries(PAGES)) def.module.mount(document.getElementById(`page-${name}`), ctx);
  ctx.openEditor = editor.init(ctx);
  renderRailStatus();
  document.getElementById('boot').remove();
  document.getElementById('app').hidden = false;
  show(pageFromHash(), false);
  ready = true;
  if (isMock) console.info('FullRecorder UI preview: running with sample data (mock bridge).');
}

start();
