// About page: version, components in use, and credits.
import { h, replace, startIcon, toast } from '../dom.js';

let ctx, root, facts;

export function mount(section, context) {
  ctx = context;
  root = section;
  facts = h('dl', { class: 'facts' });
  replace(root,
    h('div', { class: 'page-header' }, h('h1', { id: 'h-about', tabindex: '-1' }, 'About')),
    h('div', { class: 'card about-head' },
      h('img', { src: 'img/logo.png', alt: '' }),
      h('div', {},
        h('div', { class: 'about-name' }, 'FullRecorder'),
        h('div', { class: 'muted' }, `Version ${ctx.state.version}`),
        h('div', { class: 'muted' }, 'Lightweight recorder for your screen, system sound and microphone.'))),
    h('h2', { class: 'section-title' }, 'This PC'),
    h('div', { class: 'card' }, facts),
    h('h2', { class: 'section-title' }, 'Help'),
    h('div', { class: 'card row-card' },
      h('div', { class: 'grow' }, h('span', {}, 'Something not working?'),
        h('span', { class: 'muted', style: 'font-size: var(--fontSizeBase200)' }, 'The log records what FullRecorder did and why something failed.')),
      h('fluent-button', { onclick: () => ctx.call('log.open').catch((e) => toast(e.message, 'error')) }, startIcon('document_20_regular'), 'Open log')),
    h('h2', { class: 'section-title' }, 'Credits'),
    h('div', { class: 'card credits' },
      h('p', {}, 'Built with Microsoft’s Fluent 2 design system: Fluent UI Web Components, Fluent design tokens and Fluent System Icons (MIT licence).'),
      h('p', {}, 'Screen capture and encoding by FFmpeg (LGPL/GPL), installed separately. The window runs on Microsoft Edge WebView2.'),
      h('div', {}, h('fluent-button', { appearance: 'subtle', onclick: () => ctx.call('licenses.open').catch((e) => toast(e.message, 'error')) },
        'Third-party licences'))),
  );
}

export async function shown() {
  let info;
  try {
    info = await ctx.call('app.info');
  } catch (err) {
    replace(facts, h('dt', {}, 'Details'), h('dd', {}, err.message));
    return;
  }
  const row = (k, v) => [h('dt', {}, k), h('dd', {}, v ?? '—')];
  replace(facts,
    row('FFmpeg', info.ffmpegVersion ? `${info.ffmpegVersion.replace(/^ffmpeg version /, '')}` : 'Not found'),
    row('FFmpeg location', info.ffmpegPath),
    row('WebView2', info.webViewVersion),
    row('Windows', info.windows),
    row('Settings', info.settingsFile),
    row('Log and cache', info.dataFolder));
}
