// Recordings page: browse, play, trim, rename and delete saved recordings; recover unfinished ones.
import { h, icon, startIcon, replace, formatBytes, formatDuration, formatDate, toast, confirmDialog, dialogState } from '../dom.js';

let ctx, root;
let els = {};
let items = [];
let folder = '';
let freeGb = null;
let query = '';
let sort = 'newest';
let loading = false;
const recovering = new Set(); // paths being recovered (their cards are re-drawn as the folder changes)

const SORTS = {
  newest: { label: 'Newest first', fn: (a, b) => new Date(b.modified) - new Date(a.modified) },
  oldest: { label: 'Oldest first', fn: (a, b) => new Date(a.modified) - new Date(b.modified) },
  largest: { label: 'Largest first', fn: (a, b) => b.bytes - a.bytes },
  longest: { label: 'Longest first', fn: (a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0) },
  name: { label: 'Name', fn: (a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }) },
};

export function mount(section, context) {
  ctx = context;
  root = section;
  build();
  ctx.subscribe('recordings', load);
  ctx.subscribe('settings', load);
  setupRenameDialog();
}

export function shown() {
  load();
}

function build() {
  els.summary = h('p', { class: 'page-sub' });
  const search = h('fluent-text-input', { placeholder: 'Search recordings', 'aria-label': 'Search recordings', type: 'search', appearance: 'outline' },
    startIcon('search_20_regular'));
  search.addEventListener('input', () => { query = (search.value ?? '').trim().toLowerCase(); render(); });
  const sortBox = h('fluent-dropdown', { 'aria-label': 'Sort recordings', appearance: 'outline' },
    h('fluent-listbox', {},
      Object.entries(SORTS).map(([value, s]) => h('fluent-option', { value, selected: value === sort }, s.label))));
  sortBox.addEventListener('change', () => { sort = sortBox.value || 'newest'; render(); });
  customElements.whenDefined('fluent-dropdown').then(() => requestAnimationFrame(() => { sortBox.value = sort; }));
  els.info = h('span', { class: 'info' });
  els.list = h('div');

  replace(root,
    h('div', { class: 'page-header' },
      h('h1', { id: 'h-recordings', tabindex: '-1' }, 'Recordings'),
      h('div', { class: 'actions' },
        h('fluent-button', { onclick: () => ctx.call('folder.open').catch((e) => toast(e.message, 'error')) },
          startIcon('folder_open_20_regular'), 'Open folder'))),
    els.summary,
    h('div', { class: 'toolbar', role: 'search' }, search, sortBox, els.info),
    els.list);
}

async function load() {
  if (loading) return;
  loading = true;
  try {
    const res = await ctx.call('recordings.list');
    items = res.items;
    folder = res.folder;
    freeGb = res.freeGb;
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    loading = false;
  }
  render();
}

function render() {
  const total = items.reduce((n, r) => n + r.bytes, 0);
  replace(els.summary, items.length
    ? `${items.length} recording${items.length === 1 ? '' : 's'} · ${formatBytes(total)} · ${folder}`
    : folder);
  els.info.textContent = freeGb != null ? `${freeGb.toFixed(freeGb < 10 ? 1 : 0)} GB free` : '';

  if (!items.length) {
    replace(els.list, empty('No recordings yet', startHint(), 'record_24_filled', 'Start recording', () => ctx.go('record')));
    return;
  }
  const shown = items.filter((r) => !query || r.name.toLowerCase().includes(query)).sort(SORTS[sort].fn);
  if (!shown.length) {
    replace(els.list, empty('No matches', `No recording names contain “${query}”.`, null));
    return;
  }
  replace(els.list, h('ul', { class: 'grid', 'aria-label': 'Recordings' }, shown.map(card)));
}

function startHint() {
  const s = ctx.state.settings;
  const key = s.start_hotkey || s.toggle_hotkey;
  return key ? `Press ${key} anywhere or use the Record page to make your first recording.` : 'Use the Record page to make your first recording.';
}

function empty(title, text, iconName, actionLabel, action) {
  return h('div', { class: 'card empty' },
    icon('video_clip_48_regular', 'icon icon-48'),
    h('h2', {}, title),
    h('p', {}, text),
    actionLabel ? h('fluent-button', { appearance: 'primary', onclick: action }, iconName ? startIcon(iconName.replace('_24_', '_20_')) : null, actionLabel) : null);
}

function card(r) {
  if (r.unfinished) return unfinishedCard(r);
  const play = () => ctx.call('recordings.play', { path: r.path }).catch((e) => toast(e.message, 'error'));
  const meta = [formatDate(r.modified), formatBytes(r.bytes)].join(' · ');
  return h('li', { class: 'card rec-card' },
    h('button', { class: 'rec-open', type: 'button', 'aria-label': `Play ${r.name}, ${meta}`, onclick: play },
      h('div', { class: 'thumb' },
        r.thumbnail ? h('img', { src: r.thumbnail, alt: '', loading: 'lazy' }) : icon('video_20_regular', 'icon icon-24'),
        h('div', { class: 'play-overlay' }, icon('play_20_filled', 'icon')),
        r.durationSeconds ? h('span', { class: 'duration-badge' }, formatDuration(r.durationSeconds)) : null)),
    h('div', { class: 'rec-meta' },
      h('span', { class: 'rec-name', title: r.name }, r.name),
      h('span', { class: 'rec-sub' }, meta),
      moreMenu(r, play)));
}

function moreMenu(r, play) {
  const item = (iconName, label, fn) => {
    const mi = h('fluent-menu-item', {}, startIconFor(iconName), label);
    mi.addEventListener('change', fn);
    return mi;
  };
  return h('fluent-menu', { class: 'rec-more' },
    h('fluent-button', { slot: 'trigger', appearance: 'transparent', 'icon-only': true, 'aria-label': `More options for ${r.name}` },
      icon('more_horizontal_20_regular')),
    h('fluent-menu-list', {},
      item('play_20_regular', 'Play', play),
      item('cut_20_regular', 'Trim…', () => ctx.openEditor(r)),
      item('gif_20_regular', 'Make a GIF…', () => ctx.openEditor(r, 'gif')),
      item('open_20_regular', 'Show in folder', () => ctx.call('recordings.reveal', { path: r.path }).catch((e) => toast(e.message, 'error'))),
      item('rename_20_regular', 'Rename', () => openRename(r)),
      item('copy_20_regular', 'Copy file path', async () => {
        try { await ctx.call('recordings.copyPath', { path: r.path }); toast('File path copied.', 'success', 2500); }
        catch (e) { toast(e.message, 'error'); }
      }),
      h('fluent-divider', { role: 'separator' }),
      item('delete_20_regular', 'Delete', () => remove(r))));
}

/** A recording that was interrupted (crash, power cut): it can be recovered or deleted. */
function unfinishedCard(r) {
  const recover = async () => {
    if (recovering.has(r.path)) return;
    recovering.add(r.path);
    render();
    try {
      const { path, note } = await ctx.call('recordings.recover', { path: r.path });
      toast(`Recovered ${path.split(/[\\/]/).pop()}`, 'success');
      if (note) toast(note, 'warning', 10000);
    } catch (e) {
      toast(e.message, 'error', 10000);
    } finally {
      recovering.delete(r.path);
      load();
    }
  };
  const busy = recovering.has(r.path);
  const recoverBtn = h('fluent-button', { appearance: 'primary', size: 'small', disabled: busy, 'aria-label': `Recover ${r.name}` },
    busy ? h('fluent-spinner', { slot: 'start', size: 'tiny', 'aria-hidden': 'true' }) : startIcon('arrow_counterclockwise_20_regular'),
    busy ? 'Recovering…' : 'Recover');
  recoverBtn.addEventListener('click', recover);
  const meta = `${formatDate(r.modified)} · ${formatBytes(r.bytes)}${r.parts > 1 ? ` · ${r.parts} parts` : ''}`;
  return h('li', { class: 'card rec-card unfinished' },
    h('div', { class: 'thumb' },
      r.thumbnail ? h('img', { src: r.thumbnail, alt: '', loading: 'lazy' }) : icon('video_20_regular', 'icon icon-24'),
      h('fluent-badge', { class: 'unfinished-badge', appearance: 'filled', color: 'warning', shape: 'rounded' }, 'Unfinished')),
    h('div', { class: 'rec-meta' },
      h('span', { class: 'rec-name', title: r.name }, r.name),
      h('span', { class: 'rec-sub' }, meta),
      h('fluent-menu', { class: 'rec-more' },
        h('fluent-button', { slot: 'trigger', appearance: 'transparent', 'icon-only': true, 'aria-label': `More options for ${r.name}` },
          icon('more_horizontal_20_regular')),
        h('fluent-menu-list', {},
          menuItem('open_20_regular', 'Show in folder', () => ctx.call('recordings.reveal', { path: r.path }).catch((e) => toast(e.message, 'error'))),
          h('fluent-divider', { role: 'separator' }),
          menuItem('delete_20_regular', 'Delete', () => remove(r))))),
    h('div', { class: 'unfinished-note' },
      h('span', { class: 'small' }, 'This recording was interrupted (FullRecorder was closed or the PC lost power). Recover it to make a normal video.'),
      recoverBtn));
}

function menuItem(iconName, label, fn) {
  const mi = h('fluent-menu-item', {}, startIconFor(iconName), label);
  mi.addEventListener('click', fn);
  return mi;
}

function startIconFor(name) {
  const i = icon(name);
  i.slot = 'start';
  return i;
}

async function remove(r) {
  const ok = await confirmDialog({
    title: r.unfinished ? 'Delete this unfinished recording?' : 'Delete this recording?',
    text: `“${r.name}”${r.unfinished && r.parts > 1 ? ` (${r.parts} parts)` : ''} will be moved to the Recycle Bin. You can restore it from there.`,
    ok: 'Delete',
    danger: true,
  });
  if (!ok) return;
  try {
    await ctx.call('recordings.delete', { path: r.path });
    toast('Moved to the Recycle Bin.', 'success', 3000);
    await load();
  } catch (e) {
    toast(e.message, 'error');
  }
}

// ---------------------------------------------------------------- rename dialog

let renaming = null;
const INVALID = /[<>:"/\\|?*\u0000-\u001f]/;

function setupRenameDialog() {
  const dlg = document.getElementById('dlg-rename');
  const input = document.getElementById('rename-input');
  const message = document.getElementById('rename-message');
  const ok = document.getElementById('dlg-rename-ok');
  const field = document.getElementById('rename-field');

  const validate = () => {
    const v = (input.value ?? '').trim();
    let error = '';
    if (!v) error = 'Please enter a name.';
    else if (INVALID.test(v)) error = 'A name can’t contain any of these characters: < > : " / \\ | ? *';
    message.textContent = error || 'The file extension is kept.';
    field.toggleAttribute('data-invalid', !!error);
    message.style.color = error ? 'var(--colorStatusDangerForeground1)' : '';
    ok.disabled = !!error;
    return !error;
  };
  input.addEventListener('input', validate);

  const submit = async () => {
    if (!renaming || !validate()) return;
    ok.disabled = true;
    try {
      await ctx.call('recordings.rename', { path: renaming.path, name: input.value.trim() });
      dlg.hide();
      toast('Renamed.', 'success', 2500);
      load();
    } catch (e) {
      message.textContent = e.message;
      message.style.color = 'var(--colorStatusDangerForeground1)';
    } finally {
      ok.disabled = false;
    }
  };
  ok.addEventListener('click', submit);
  document.getElementById('rename-form').addEventListener('submit', (e) => { e.preventDefault(); submit(); });
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
  document.getElementById('dlg-rename-cancel').addEventListener('click', () => dlg.hide());
  dlg.addEventListener('toggle', (e) => { if (dialogState(e) === 'closed') renaming = null; });

  els.openRename = (r) => {
    renaming = r;
    const dot = r.name.lastIndexOf('.');
    input.value = dot > 0 ? r.name.slice(0, dot) : r.name;
    validate();
    dlg.show();
    requestAnimationFrame(() => { input.focus(); input.select?.(); });
  };
}

function openRename(r) {
  els.openRename(r);
}
