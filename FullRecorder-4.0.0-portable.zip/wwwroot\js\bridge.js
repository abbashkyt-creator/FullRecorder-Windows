// Messages between this page and the FullRecorder app (see Ui/Bridge.cs).
// In a normal browser (design preview) a mock with sample data is used instead.

const host = window.chrome?.webview;
const pending = new Map();
const listeners = new Map();
let nextId = 1;
let mock = null;

export const isMock = !host;

if (host) {
  host.addEventListener('message', (e) => receive(e.data));
}

function receive(msg) {
  if (!msg || typeof msg !== 'object') return;
  if ('event' in msg) {
    for (const fn of listeners.get(msg.event) ?? []) {
      try { fn(msg.data); } catch (err) { console.error(err); }
    }
    return;
  }
  const p = pending.get(msg.id);
  if (!p) return;
  pending.delete(msg.id);
  if (msg.ok) p.resolve(msg.result);
  else p.reject(new Error(msg.error || 'Something went wrong.'));
}

/** Calls the app. Resolves with the result or rejects with a user-readable Error. */
export async function call(method, params = {}) {
  if (!host) {
    mock ??= await import('./mock.js');
    return mock.call(method, params, receive);
  }
  const id = nextId++;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    host.postMessage({ id, method, params });
  });
}

/** Listens for an app event ("status", "recordings", "saved", "problem", "navigate"). */
export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  if (!host) import('./mock.js').then((m) => { mock = m; m.attach(receive); });
  return () => listeners.get(event)?.delete(fn);
}
