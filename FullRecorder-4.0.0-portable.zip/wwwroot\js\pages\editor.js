// Trim / GIF dialog: preview a recording, choose a start and end, save a trimmed copy or a GIF.
// The original recording is never changed.
import { h, replace, toast, formatTime, parseTime, dialogState } from '../dom.js';
import { on } from '../bridge.js';

let ctx;
let dlg, video, els = {};
let rec = null;         // the recording being edited
let duration = 0;
let range = { start: 0, end: 0 };
let job = null;         // { id } while a save is running
let opener = null;      // what had focus when the dialog opened (focus goes back there)

export function init(context) {
  ctx = context;
  build();
  on('job', onJob);
  return open;
}

function build() {
  video = h('video', { class: 'editor-video', controls: true, preload: 'metadata', 'aria-label': 'Preview',
    controlsList: 'nodownload noremoteplayback noplaybackrate', disablePictureInPicture: true });
  video.addEventListener('loadedmetadata', () => {
    if (isFinite(video.duration) && video.duration > 0) {
      duration = video.duration;
      if (range.end <= 0 || range.end > duration) range.end = duration;
      render();
    }
  });
  video.addEventListener('timeupdate', renderPlayhead);
  video.addEventListener('error', () => {
    els.previewNote.hidden = false;
    video.hidden = true;
  });

  els.title = h('h2', { slot: 'title', id: 'dlg-editor-title' }, 'Trim or make a GIF');
  els.previewNote = h('p', { class: 'editor-note', hidden: true });
  els.bar = h('div', { class: 'range-bar', 'aria-hidden': 'true' },
    els.sel = h('div', { class: 'range-sel' }),
    els.head = h('div', { class: 'range-head' }));
  els.bar.addEventListener('click', (e) => {
    if (!duration || video.hidden) return;
    const r = els.bar.getBoundingClientRect();
    video.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * duration;
  });
  els.start = timeField('start', 'Start');
  els.end = timeField('end', 'End');
  els.length = h('span', { class: 'editor-length mono' });

  els.mode = h('fluent-radio-group', { orientation: 'horizontal', 'aria-label': 'What to make', name: 'editor-mode' },
    h('fluent-field', { 'label-position': 'after' }, h('label', { slot: 'label', for: 'em-trim' }, 'A trimmed video'),
      h('fluent-radio', { slot: 'input', id: 'em-trim', name: 'editor-mode', value: 'trim', checked: true })),
    h('fluent-field', { 'label-position': 'after' }, h('label', { slot: 'label', for: 'em-gif' }, 'An animated GIF'),
      h('fluent-radio', { slot: 'input', id: 'em-gif', name: 'editor-mode', value: 'gif' })));
  els.mode.addEventListener('change', render);

  els.reencodeBox = h('fluent-checkbox', { slot: 'input', id: 'em-reencode' });
  els.reencodeRow = h('fluent-field', { 'label-position': 'after', class: 'check-row' },
    h('label', { slot: 'label', for: 'em-reencode' }, 'Re-encode for exact cuts in every app'),
    els.reencodeBox,
    h('fluent-text', { slot: 'message', size: '200' }, 'Slower. Without it the cut is still exact in most players, with no loss of quality.'));
  els.gifWidth = select('GIF width', [[480, '480 px'], [640, '640 px'], [800, '800 px'], [960, '960 px']], 640);
  els.gifFps = select('GIF frame rate', [[10, '10 fps'], [15, '15 fps'], [20, '20 fps']], 15);
  els.gifRow = h('div', { class: 'editor-row', hidden: true }, els.gifWidth, els.gifFps,
    h('span', { class: 'muted small' }, 'GIFs get large quickly; up to 60 seconds.'));

  els.progress = h('fluent-progress-bar', { max: '100', value: '0', hidden: true, 'aria-label': 'Progress' });
  els.message = h('p', { class: 'editor-message', role: 'status' });
  els.cancel = h('fluent-button', { slot: 'action', onclick: onCancel }, 'Close');
  els.ok = h('fluent-button', { slot: 'action', appearance: 'primary', onclick: onSave }, 'Save trimmed copy');

  dlg = h('fluent-dialog', { id: 'dlg-editor', type: 'modal', 'aria-labelledby': 'dlg-editor-title', class: 'editor-dialog' },
    h('fluent-dialog-body', {},
      els.title,
      h('div', { class: 'editor' },
        h('div', { class: 'editor-media' }, video, els.previewNote),
        els.bar,
        h('div', { class: 'editor-row' },
          els.start.wrap,
          h('fluent-button', { size: 'small', onclick: () => setFromPlayhead('start'), title: 'Shortcut: I', 'aria-keyshortcuts': 'I' }, 'Set start here'),
          els.end.wrap,
          h('fluent-button', { size: 'small', onclick: () => setFromPlayhead('end'), title: 'Shortcut: O', 'aria-keyshortcuts': 'O' }, 'Set end here'),
          els.length),
        els.mode,
        els.reencodeRow,
        els.gifRow,
        els.progress,
        els.message),
      els.cancel,
      els.ok));
  dlg.addEventListener('keydown', (e) => {
    if (e.target instanceof HTMLInputElement || e.target?.tagName === 'FLUENT-TEXT-INPUT') return;
    if (e.key === 'i' || e.key === 'I') { setFromPlayhead('start'); e.preventDefault(); }
    if (e.key === 'o' || e.key === 'O') { setFromPlayhead('end'); e.preventDefault(); }
  });
  dlg.addEventListener('toggle', (e) => {
    if (dialogState(e) !== 'closed') return;
    // Closing (also with Esc or the backdrop) stops the preview and any save in progress.
    if (job) ctx.call('jobs.cancel', { job: job.id }).catch(() => {});
    video.pause();
    video.removeAttribute('src');
    video.load();
    const back = opener;
    opener = null;
    requestAnimationFrame(() => (back?.isConnected ? back : document.querySelector('#content h1'))?.focus?.());
  });
  document.body.append(dlg);
}

function timeField(key, label) {
  const input = h('input', { class: 'time-input mono', type: 'text', inputmode: 'decimal', 'aria-label': `${label} time`, spellcheck: 'false' });
  input.addEventListener('change', () => {
    const t = parseTime(input.value);
    if (isNaN(t)) { render(); return; }
    range[key] = Math.max(0, duration ? Math.min(t, duration) : t);
    if (range.end < range.start) [range.start, range.end] = [range.end, range.start];
    if (!video.hidden && duration) video.currentTime = range[key];
    render();
  });
  return { input, wrap: h('label', { class: 'time-field' }, h('span', { class: 'muted small' }, label), input) };
}

function select(label, options, value) {
  const dd = h('fluent-dropdown', { 'aria-label': label, appearance: 'outline', class: 'small-dropdown' },
    h('fluent-listbox', {}, options.map(([v, text]) => h('fluent-option', { value: String(v), selected: v === value }, text))));
  customElements.whenDefined('fluent-dropdown').then(() => requestAnimationFrame(() => { dd.value = String(value); }));
  return dd;
}

function setFromPlayhead(key) {
  if (video.hidden || !duration) return;
  range[key] = video.currentTime;
  if (range.end < range.start) [range.start, range.end] = key === 'start' ? [range.start, duration] : [0, range.end];
  render();
}

async function open(r, mode = 'trim') {
  if (job) { toast('Wait for the current save to finish, or cancel it.', 'info'); return; }
  opener = document.activeElement;
  rec = r;
  duration = r.durationSeconds ?? 0;
  range = { start: 0, end: duration };
  els.title.textContent = `Trim or make a GIF: ${r.name}`;
  els.previewNote.hidden = true;
  els.previewNote.textContent = /\.mkv$/i.test(r.name)
    ? 'MKV recordings can’t be previewed here, but you can still type the start and end times.'
    : 'The preview couldn’t be loaded, but you can still type the start and end times.';
  video.hidden = false;
  els.message.textContent = '';
  els.progress.hidden = true;
  els.reencodeBox.checked = false;
  els.message.dataset.kind = '';
  dlg.show();
  requestAnimationFrame(() => { els.mode.value = mode; render(); });
  render();
  try {
    const { url } = await ctx.call('recordings.media', { path: r.path });
    if (rec === r) video.src = url;
  } catch (err) {
    els.previewNote.hidden = false;
    video.hidden = true;
  }
}

function render() {
  const gif = els.mode.value === 'gif';
  els.reencodeRow.hidden = gif;
  els.gifRow.hidden = !gif;
  els.ok.textContent = gif ? 'Make GIF' : 'Save trimmed copy';
  if (document.activeElement !== els.start.input) els.start.input.value = formatTime(range.start);
  if (document.activeElement !== els.end.input) els.end.input.value = formatTime(range.end);
  const len = Math.max(0, range.end - range.start);
  els.length.textContent = `Length ${formatTime(len)}`;
  // With the length unknown (no preview), the bar shows nothing rather than overflowing.
  const total = duration || 0;
  els.sel.style.left = total ? `${Math.min(100, (range.start / total) * 100)}%` : '0';
  els.sel.style.width = total ? `${Math.min(100, (len / total) * 100)}%` : '0';
  els.ok.disabled = !!job || len < 0.1 || (gif && len > 60);
  if (gif && len > 60 && !job) els.message.textContent = 'A GIF can be at most 60 seconds. Choose a shorter part.';
  else if (!job && els.message.dataset.kind !== 'result') els.message.textContent = '';
  renderPlayhead();
}

function renderPlayhead() {
  els.head.hidden = !duration;
  if (duration) els.head.style.left = `${Math.min(100, (video.currentTime / duration) * 100)}%`;
}

async function onSave() {
  if (!rec || job) return;
  const gif = els.mode.value === 'gif';
  const id = `job-${Date.now()}`;
  const mine = { id };
  job = mine;
  els.progress.hidden = false;
  els.progress.value = '0';
  els.message.dataset.kind = '';
  els.message.textContent = gif ? 'Making the GIF…' : 'Saving the trimmed copy…';
  els.cancel.textContent = 'Cancel';
  render();
  try {
    const params = { job: id, path: rec.path, start: range.start, end: range.end };
    const result = gif
      ? await ctx.call('recordings.gif', { ...params, width: Number(els.gifWidth.value), fps: Number(els.gifFps.value) })
      : await ctx.call('recordings.trim', { ...params, reencode: els.reencodeBox.checked });
    const name = result.path.split(/[\\/]/).pop();
    toast(`Saved ${name}`, 'success');
    if (job !== mine) return; // the dialog was closed meanwhile
    els.message.dataset.kind = 'result';
    replace(els.message, `Saved as “${name}”. `,
      h('fluent-button', { appearance: 'transparent', size: 'small', onclick: () => ctx.call('recordings.reveal', { path: result.path }).catch((er) => toast(er.message, 'error')) },
        'Show in folder'));
  } catch (err) {
    if (job !== mine) return;
    els.message.dataset.kind = 'result';
    els.message.textContent = err.message === 'Cancelled.' ? 'Cancelled. Nothing was saved.' : err.message;
  } finally {
    if (job === mine) {
      job = null;
      els.progress.hidden = true;
      els.cancel.textContent = 'Close';
      render();
    }
  }
}

function onCancel() {
  if (job) {
    ctx.call('jobs.cancel', { job: job.id }).catch(() => {});
    return;
  }
  dlg.hide();
}

function onJob({ id, progress }) {
  if (!job || job.id !== id) return;
  els.progress.value = String(Math.round(progress * 100));
}
