// Settings page, in the Windows 11 Settings style: grouped cards, changes apply immediately.
import { h, icon, startIcon, replace, keycaps, settingRow, toast, confirmDialog, formatDuration } from '../dom.js';

let ctx, root;
const sync = new Map();     // setting key -> function that shows the current value
let devices = null;
let info = null;
let cameras = null;
let els = {};

export function mount(section, context) {
  ctx = context;
  root = section;
  build();
  ctx.subscribe('settings', syncAll);
  ctx.subscribe('hotkeys', syncAll);
  ctx.subscribe('replay', renderReplayStatus);
  ctx.subscribe('status', renderRecordingNotice);
  load();
}

export function shown() {
  load();
}

export function hidden() {
  // Never leave the app's shortcuts paused.
  ctx.call('hotkeys.capture', { active: false }).catch(() => {});
}

async function load() {
  try {
    [devices, info] = await Promise.all([ctx.call('devices.list'), ctx.call('app.info')]);
    loadCameras();
  } catch {
    // keep what we have
  }
  rebuildDynamic();
  syncAll();
}

const S = () => ctx.state.settings;

async function loadCameras() {
  try {
    ({ cameras } = await ctx.call('cameras.list'));
  } catch {
    cameras = cameras ?? [];
  }
  syncAll();
}

/** "Keeping the last 2:00 · 1:23 so far" and friends. */
export function replayText(r, enabled) {
  if (!enabled) return 'Off.';
  switch (r?.state) {
    case 'running': return `Keeping the last ${formatDuration(r.seconds)} · ${formatDuration(r.bufferedSeconds)} kept so far.`;
    case 'starting': return 'Starting…';
    case 'waitingforpower': return 'Waiting: the PC is on battery (switch on “Keep it running on battery” to change this).';
    case 'failed': return `Couldn’t start: ${r.error ?? 'unknown problem'}`;
    default: return 'Starting…';
  }
}

function renderReplayStatus() {
  if (!els.replayStatus) return;
  const r = ctx.state.replay;
  const shortcutProblem = S().replay_enabled ? ctx.state.hotkeyErrors?.replay_hotkey : null;
  els.replayStatus.textContent = replayText(r, S().replay_enabled) + (shortcutProblem ? ` ${shortcutProblem}` : '');
  els.replayStatus.classList.toggle('error', r?.state === 'failed' || !!shortcutProblem);
}

// ---------------------------------------------------------------- controls

async function save(key, value, revert) {
  try {
    await ctx.setSetting(key, value);
    return true;
  } catch (err) {
    toast(err.message, 'error');
    revert?.();
    syncAll();
    return false;
  }
}

function switchCtl(key, label) {
  const sw = h('fluent-switch', { 'aria-label': label });
  sw.addEventListener('change', () => save(key, sw.checked));
  sync.set(key, () => { sw.checked = !!S()[key]; });
  return sw;
}

function dropdownCtl(key, label, options) {
  const dd = h('fluent-dropdown', { 'aria-label': label, appearance: 'outline' });
  let signature = '';
  const fill = () => {
    const current = String(S()[key] ?? '');
    const opts = typeof options === 'function' ? options() : options;
    const list = opts.some((o) => String(o.value) === current) ? opts : [...opts, { value: current, label: `Custom (${current})` }];
    const sig = JSON.stringify(list);
    if (sig !== signature) {
      signature = sig;
      // Fluent v3: options live in a fluent-listbox inside the dropdown.
      replace(dd, h('fluent-listbox', {},
        list.map((o) => h('fluent-option', { value: String(o.value), selected: String(o.value) === current }, o.label))));
    }
    requestAnimationFrame(() => {
      for (const o of dd.querySelectorAll('fluent-option')) o.selected = o.value === current;
      if (dd.value !== current) dd.value = current;
    });
  };
  dd.addEventListener('change', () => {
    if (dd.value != null && String(dd.value) !== String(S()[key])) save(key, dd.value);
  });
  sync.set(key, fill);
  return dd;
}

function sliderCtl(key, label, { min, max, step, toUi = (v) => v, fromUi = (v) => v, format }) {
  const value = h('span', { class: 'slider-value', 'aria-hidden': 'true' });
  const slider = h('fluent-slider', { min: String(min), max: String(max), step: String(step), 'aria-label': label });
  let timer = null;
  slider.addEventListener('change', () => {
    const ui = Number(slider.value);
    value.textContent = format(ui);
    slider.setAttribute('aria-valuetext', format(ui));
    clearTimeout(timer);
    timer = setTimeout(() => {
      const v = fromUi(ui);
      if (Math.abs(v - Number(S()[key])) > 1e-9) save(key, v);
    }, 350);
  });
  sync.set(key, () => {
    const ui = toUi(Number(S()[key]));
    if (document.activeElement !== slider) slider.value = String(ui);
    value.textContent = format(ui);
    slider.setAttribute('aria-valuetext', format(ui));
  });
  return h('div', { class: 'slider-row' }, slider, value);
}

function textCtl(key, label, placeholder) {
  const input = h('fluent-text-input', { 'aria-label': label, placeholder, appearance: 'outline', spellcheck: 'false' });
  input.addEventListener('change', () => save(key, (input.value ?? '').trim()));
  sync.set(key, () => { if (document.activeElement !== input) input.value = S()[key] ?? ''; });
  return input;
}

// ---------------------------------------------------------------- shortcut recorder

const CODE_TO_KEY = {
  Space: 'Space', Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown', Insert: 'Insert', Delete: 'Delete',
  ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right', Pause: 'Pause', ScrollLock: 'Scroll',
  PrintScreen: 'PrintScreen', Backquote: 'Oemtilde', Minus: 'OemMinus', Equal: 'Oemplus', BracketLeft: 'OemOpenBrackets',
  BracketRight: 'OemCloseBrackets', Backslash: 'OemPipe', Semicolon: 'OemSemicolon', Quote: 'OemQuotes', Comma: 'Oemcomma',
  Period: 'OemPeriod', Slash: 'OemQuestion', NumpadAdd: 'Add', NumpadSubtract: 'Subtract', NumpadMultiply: 'Multiply',
  NumpadDivide: 'Divide', NumpadDecimal: 'Decimal',
};

/** The key part of a shortcut from KeyboardEvent.code, in the names FullRecorder understands. */
export function keyFromCode(code) {
  if (/^Key[A-Z]$/.test(code)) return code.slice(3);
  if (/^Digit\d$/.test(code)) return code.slice(5);
  if (/^F\d{1,2}$/.test(code)) return code;
  if (/^Numpad\d$/.test(code)) return `NumPad${code.slice(6)}`;
  return CODE_TO_KEY[code] ?? null;
}

const MODIFIER_CODES = new Set(['ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'ShiftLeft', 'ShiftRight', 'MetaLeft', 'MetaRight']);

function hotkeyCtl(key, label, descEl) {
  const box = h('button', { class: 'hotkey', type: 'button', 'aria-label': `Shortcut for: ${label}` });
  const clear = h('fluent-button', { appearance: 'subtle', 'icon-only': true, 'aria-label': `Remove the shortcut for: ${label}`, title: 'Remove shortcut' },
    icon('dismiss_20_regular'));
  let capturing = false;
  const defaultDesc = descEl.textContent;

  const setDesc = (text, error) => {
    descEl.textContent = text;
    descEl.classList.toggle('error', !!error);
  };
  const show = () => {
    const spec = S()[key];
    replace(box, capturing ? h('span', { class: 'placeholder' }, 'Press a shortcut… (Esc to cancel)') : keycaps(spec));
    box.dataset.capturing = String(capturing);
    const problem = ctx.state.hotkeyErrors?.[key];
    box.setAttribute('aria-description', capturing ? 'Recording a shortcut. Press keys now, or Escape to cancel.'
      : `Current shortcut: ${spec || 'none'}.${problem ? ` ${problem}` : ''} Press Enter to change.`);
    clear.hidden = capturing || !spec;
    if (!capturing) setDesc(problem ? `${problem} Choose another shortcut.` : defaultDesc, !!problem);
  };
  const begin = async () => {
    if (capturing) return;
    capturing = true;
    setDesc('Press the keys together, for example Ctrl+Shift+G.');
    show();
    try { await ctx.call('hotkeys.capture', { active: true }); } catch { /* still works for keys nobody else uses */ }
  };
  const end = async () => {
    if (!capturing) return;
    capturing = false;
    show();
    try { await ctx.call('hotkeys.capture', { active: false }); } catch { /* ignore */ }
  };

  box.addEventListener('click', begin);
  box.addEventListener('blur', () => { if (capturing) end(); else show(); });
  box.addEventListener('keydown', async (e) => {
    if (!capturing) return;
    e.preventDefault();
    e.stopPropagation();
    if (MODIFIER_CODES.has(e.code)) return;
    if (e.code === 'Escape' && !e.ctrlKey && !e.altKey && !e.shiftKey && !e.metaKey) { await end(); setDesc(defaultDesc); return; }
    const k = keyFromCode(e.code);
    if (!k) { setDesc('That key can’t be used in a shortcut. Try a letter, number or F-key.', true); return; }
    const mods = [e.ctrlKey && 'Ctrl', e.altKey && 'Alt', e.shiftKey && 'Shift', e.metaKey && 'Win'].filter(Boolean);
    if (!mods.length) { setDesc('Add Ctrl, Alt, Shift or the Windows key, so the shortcut doesn’t get in the way of typing.', true); return; }
    const spec = [...mods, k].join('+');
    await end();
    try {
      await ctx.setSetting(key, spec);
      setDesc(defaultDesc);
      toast(`${label}: ${S()[key]}`, 'success', 2500);
    } catch (err) {
      setDesc(err.message, true);
    }
  });
  clear.addEventListener('click', async () => {
    try { await ctx.setSetting(key, ''); } catch (err) { toast(err.message, 'error'); }
  });

  sync.set(key, show);
  return h('div', { class: 'setting-control' }, box, clear);
}

// ---------------------------------------------------------------- page

function section(title, ...rows) {
  return [h('h2', { class: 'section-title' }, title), h('div', { class: 'card' }, rows)];
}

function build() {
  els.notice = h('div');
  els.monitor = h('div', { style: 'display:contents' });
  els.ffmpeg = h('div', { style: 'display:contents' });
  els.sysDevice = h('div', { style: 'display:contents' });
  els.micDevice = h('div', { style: 'display:contents' });
  els.ownSounds = h('div', { style: 'display:contents' });
  // Not a live region: it changes every second while the buffer fills.
  els.replayStatus = h('span', { class: 'setting-desc' });
  els.startup = h('fluent-switch', { 'aria-label': 'Start FullRecorder when I sign in' });
  els.startup.addEventListener('change', async () => {
    try {
      const r = await ctx.call('startup.set', { enabled: els.startup.checked });
      ctx.state.startup = r.enabled;
    } catch (err) {
      toast(err.message, 'error');
    }
    els.startup.checked = ctx.state.startup;
  });

  const folderPath = h('span', { class: 'path' });
  sync.set('output_folder', () => { folderPath.textContent = S().output_folder; folderPath.title = S().output_folder; });

  const hotkeyRow = (key, label, iconName, help) => {
    const desc = h('span', { class: 'setting-desc' }, help);
    return settingRow({ iconName, label, desc, control: hotkeyCtl(key, label, desc) });
  };

  const soundVolume = h('div', { class: 'setting-control' },
    sliderCtl('sound_volume', 'Sound volume', { min: 0, max: 100, step: 5, toUi: (v) => Math.round(v * 100), fromUi: (v) => v / 100, format: (v) => `${v}%` }),
    h('fluent-button', { onclick: () => ctx.call('sounds.test') }, 'Test'));

  replace(root,
    h('div', { class: 'page-header' }, h('h1', { id: 'h-settings', tabindex: '-1' }, 'Settings')),
    h('p', { class: 'page-sub' }, 'Changes are saved as soon as you make them.'),
    els.notice,

    ...section('Recording',
      settingRow({ iconName: 'folder_open_20_regular', label: 'Save recordings to', desc: folderPath,
        control: [h('fluent-button', { onclick: pickFolder }, 'Change…'),
          h('fluent-button', { appearance: 'subtle', onclick: () => ctx.call('folder.open').catch((e) => toast(e.message, 'error')) }, 'Open')] }),
      settingRow({ iconName: 'document_20_regular', label: 'File name', desc: '{date} and {time} are filled in when you record.',
        control: textCtl('file_name', 'File name', 'Recording_{date}_{time}') }),
      settingRow({ iconName: 'video_20_regular', label: 'File type', desc: 'MP4 plays everywhere. Either way, a recording survives a crash or power cut and can be recovered.',
        control: dropdownCtl('container', 'File type', [{ value: 'mp4', label: 'MP4 (recommended)' }, { value: 'mkv', label: 'MKV' }]) }),
      settingRow({ iconName: 'filmstrip_20_regular', label: 'Video format',
        desc: 'HEVC files are about half the size. Windows’ own apps play HEVC only with the HEVC Video Extensions from the Microsoft Store.',
        control: dropdownCtl('video_codec', 'Video format', [{ value: 'h264', label: 'H.264 (plays everywhere)' }, { value: 'hevc', label: 'HEVC (smaller files)' }]) }),
      settingRow({ iconName: 'top_speed_20_regular', label: 'Video quality', desc: 'Higher quality makes bigger files.',
        control: dropdownCtl('quality', 'Video quality', [
          { value: 18, label: 'Highest' }, { value: 21, label: 'High' }, { value: 23, label: 'Balanced (recommended)' },
          { value: 26, label: 'Smaller files' }, { value: 30, label: 'Smallest files' }]) }),
      settingRow({ iconName: 'timer_20_regular', label: 'Frame rate', desc: '60 makes fast motion and games smoother; 30 is enough for most screens.',
        control: dropdownCtl('fps', 'Frame rate', [{ value: 24, label: '24 fps' }, { value: 30, label: '30 fps (recommended)' }, { value: 60, label: '60 fps' }]) }),
      els.monitor,
      settingRow({ iconName: 'cursor_20_regular', label: 'Show the mouse pointer', control: switchCtl('capture_cursor', 'Show the mouse pointer') }),
      settingRow({ iconName: 'data_bar_vertical_20_regular', label: 'Video encoder', desc: 'Automatic picks the lightest method that works on this PC.',
        control: dropdownCtl('encoder', 'Video encoder', () => {
          const base = [{ value: 'auto', label: 'Automatic (recommended)' }, { value: 'nvidia', label: 'NVIDIA graphics' },
            { value: 'intel', label: 'Intel graphics' }, { value: 'cpu', label: 'Processor only' }];
          return base;
        }) }),
      settingRow({ iconName: 'eye_off_20_regular', label: 'Keep this window out of recordings', desc: 'FullRecorder’s own window never appears in your videos.',
        control: switchCtl('hide_from_capture', 'Keep this window out of recordings') }),
      settingRow({ iconName: 'window_20_regular', label: 'Hide this window when recording starts',
        control: switchCtl('hide_window_on_record', 'Hide this window when recording starts') }),
    ),

    ...section('Sound',
      settingRow({ iconName: 'speaker_2_20_regular', label: 'System sound', desc: 'Everything you hear from the PC: videos, calls, games, notifications.',
        control: switchCtl('system_audio', 'Record system sound') }),
      els.sysDevice,
      els.ownSounds,
      settingRow({ label: 'When recording one window', sub: true,
        desc: 'Only that app’s sound leaves out notifications and other apps. (Uses the default speakers.)',
        control: dropdownCtl('window_audio', 'System sound when recording one window', [
          { value: 'all', label: 'Record all system sound' }, { value: 'app', label: 'Record only that app’s sound' }]) }),
      settingRow({ label: 'System sound volume', sub: true,
        control: sliderCtl('system_volume', 'System sound volume', { min: 0, max: 200, step: 5, toUi: (v) => Math.round(v * 100), fromUi: (v) => v / 100, format: (v) => `${v}%` }) }),
      settingRow({ iconName: 'mic_20_regular', label: 'Microphone', desc: 'Your voice.', control: switchCtl('microphone', 'Record the microphone') }),
      els.micDevice,
      settingRow({ label: 'Microphone volume', sub: true,
        control: sliderCtl('microphone_volume', 'Microphone volume', { min: 0, max: 200, step: 5, toUi: (v) => Math.round(v * 100), fromUi: (v) => v / 100, format: (v) => `${v}%` }) }),
      settingRow({ iconName: 'layer_20_regular', label: 'Also save system sound and microphone separately',
        desc: 'Adds two extra audio tracks for video editing. Players still play the mix.',
        control: switchCtl('separate_tracks', 'Save separate audio tracks') }),
      settingRow({ iconName: 'music_note_2_20_regular', label: 'Sound quality',
        control: dropdownCtl('audio_bitrate_kbps', 'Sound quality', [{ value: 128, label: 'Standard (128 kbps)' }, { value: 192, label: 'High (192 kbps, recommended)' }, { value: 256, label: 'Very high (256 kbps)' }, { value: 320, label: 'Maximum (320 kbps)' }]) }),
      settingRow({ iconName: 'timer_20_regular', label: 'System sound delay',
        desc: 'Only if system sound is out of step with the picture, for example with Bluetooth headphones.',
        control: sliderCtl('system_audio_offset_ms', 'System sound delay', { min: -500, max: 500, step: 10, format: (v) => `${v > 0 ? '+' : ''}${v} ms` }) }),
    ),

    ...section('Extras',
      settingRow({ iconName: 'replay_20_regular', label: 'Instant replay',
        desc: 'Keeps the last minutes of your screen and sound, so you can save them after something happens. The graphics card works all the time (about 7 W on the test laptop), so it waits while the PC is on battery unless you allow it. Changing what is recorded (screen, quality, sound sources) starts it afresh.',
        control: switchCtl('replay_enabled', 'Instant replay') }),
      settingRow({ label: 'Keep the last', sub: true,
        control: dropdownCtl('replay_seconds', 'Instant replay length', [30, 60, 120, 300, 600].map((n) => ({ value: n, label: n < 60 ? `${n} seconds` : `${n / 60} minute${n === 60 ? '' : 's'}` }))) }),
      settingRow({ label: 'Keep it running on battery', sub: true, control: switchCtl('replay_on_battery', 'Keep instant replay running on battery') }),
      settingRow({ label: 'Status', sub: true, desc: els.replayStatus, control: null }),
      settingRow({ iconName: 'video_person_20_regular', label: 'Camera bubble',
        desc: 'A round picture from your camera that is recorded with the screen. Drag it where you want it. (Not in recordings of one window.)',
        control: dropdownCtl('webcam', 'Camera bubble', [{ value: 'off', label: 'Off' }, { value: 'recording', label: 'While recording' }, { value: 'always', label: 'Always' }]) }),
      settingRow({ label: 'Camera', sub: true,
        control: [dropdownCtl('webcam_device', 'Camera', () => [{ value: '', label: 'First camera found' }, ...(cameras ?? []).map((c) => ({ value: c, label: c }))]),
          h('fluent-button', { appearance: 'subtle', 'icon-only': true, 'aria-label': 'Look for cameras again', title: 'Refresh', onclick: loadCameras }, icon('arrow_clockwise_20_regular'))] }),
      settingRow({ label: 'Size', sub: true,
        control: dropdownCtl('webcam_size', 'Camera bubble size', [{ value: 'small', label: 'Small' }, { value: 'medium', label: 'Medium' }, { value: 'large', label: 'Large' }]) }),
      settingRow({ label: 'Show it like a mirror', sub: true, control: switchCtl('webcam_mirror', 'Show the camera like a mirror') }),
      settingRow({ iconName: 'cursor_click_20_regular', label: 'Highlight mouse clicks',
        desc: 'A short ring where you click, while recording the screen or an area. Left click amber, right click blue.',
        control: switchCtl('click_highlights', 'Highlight mouse clicks') }),
    ),

    ...section('Shortcuts',
      hotkeyRow('start_hotkey', 'Start recording', 'record_20_filled', 'Works anywhere in Windows while FullRecorder is running.'),
      hotkeyRow('stop_hotkey', 'Stop and save', 'stop_20_filled', 'Stops the recording and saves the video.'),
      hotkeyRow('pause_hotkey', 'Pause or resume', 'pause_20_filled', 'Nothing is recorded while paused; the parts are joined into one video.'),
      hotkeyRow('replay_hotkey', 'Save instant replay', 'replay_20_regular', 'Saves the last minutes. Works while instant replay is on.'),
      hotkeyRow('toggle_hotkey', 'Start or stop (one key for both)', 'arrow_sync_20_regular', 'Optional: the same shortcut starts and stops.'),
      hotkeyRow('quit_hotkey', 'Quit FullRecorder', 'power_20_regular', 'Closes FullRecorder completely.'),
    ),

    ...section('General',
      settingRow({ iconName: 'power_20_regular', label: 'Start FullRecorder when I sign in', desc: 'Starts quietly in the background, ready for your shortcut.', control: els.startup }),
      settingRow({ iconName: 'panel_bottom_20_regular', label: 'Show FullRecorder in the notification area', desc: 'An icon by the clock to start, stop and open FullRecorder.',
        control: switchCtl('tray_icon', 'Show FullRecorder in the notification area') }),
      settingRow({ iconName: 'alert_badge_20_regular', label: 'Tell me when a recording is saved', desc: 'A Windows notification you can click to see your recordings.',
        control: switchCtl('notify_saved', 'Tell me when a recording is saved') }),
      settingRow({ iconName: 'music_note_2_20_regular', label: 'Start and stop sounds', desc: 'Short beeps that are never included in recordings.',
        control: switchCtl('sounds', 'Start and stop sounds') }),
      settingRow({ label: 'Sound volume', sub: true, control: soundVolume }),
      settingRow({ iconName: 'dark_theme_20_regular', label: 'App theme',
        control: dropdownCtl('theme', 'App theme', [{ value: 'system', label: 'Use Windows setting' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }]) }),
    ),

    ...section('Advanced',
      els.ffmpeg,
      settingRow({ iconName: 'hard_drive_20_regular', label: 'Stop when free disk space is below',
        control: dropdownCtl('min_free_space_gb', 'Minimum free disk space', [1, 2, 5, 10, 20].map((n) => ({ value: n, label: `${n} GB` }))) }),
      settingRow({ iconName: 'document_20_regular', label: 'Settings file and log',
        control: [h('fluent-button', { onclick: () => ctx.call('settings.openFile').catch((e) => toast(e.message, 'error')) }, 'Open settings file'),
          h('fluent-button', { onclick: () => ctx.call('log.open').catch((e) => toast(e.message, 'error')) }, 'Open log')] }),
      settingRow({ iconName: 'arrow_reset_20_regular', label: 'Reset all settings', desc: 'Your recordings and the “start when I sign in” choice are kept.',
        control: h('fluent-button', { onclick: resetAll }, 'Reset') }),
    ),
  );
  rebuildDynamic();
  syncAll();
}

function rebuildDynamic() {
  const displays = devices?.displays ?? [{ index: 0, name: 'Display 1 (main)', width: 0, height: 0 }];
  replace(els.monitor, settingRow({ iconName: 'desktop_20_regular', label: 'Screen to record',
    control: dropdownCtl('monitor', 'Screen to record', displays.map((d) => ({ value: d.index, label: d.width ? `${d.name} · ${d.width} × ${d.height}` : d.name }))) }));

  const deviceOptions = (list) => [{ value: '', label: 'Windows default' }, ...(list ?? []).map((d) => ({ value: d.name, label: d.name + (d.isDefault ? ' (default)' : '') }))];
  replace(els.sysDevice, settingRow({ label: 'Speakers or headphones', sub: true,
    control: dropdownCtl('system_device', 'Speakers or headphones', () => deviceOptions(devices?.speakers)) }));
  replace(els.micDevice, settingRow({ label: 'Microphone device', sub: true,
    control: dropdownCtl('microphone_device', 'Microphone device', () => deviceOptions(devices?.microphones)) }));

  const supported = ctx.state.appSoundSupported !== false;
  replace(els.ownSounds, settingRow({ label: 'Leave FullRecorder’s beeps out of recordings', sub: true,
    desc: supported ? 'The start, pause and stop beeps are never recorded. (Uses the default speakers; with a specific device chosen above, beeps are timed so they’re not recorded instead.)'
      : 'Needs Windows 10 version 2004 or later. Beeps are timed so they’re not recorded instead.',
    control: switchCtl('exclude_own_sounds', 'Leave FullRecorder’s beeps out of recordings') }));

  const custom = !!S().ffmpeg_path;
  const desc = info?.ffmpegPath
    ? `${custom ? 'Chosen' : 'Found automatically'}: ${info.ffmpegPath}${info.ffmpegVersion ? ` (${info.ffmpegVersion.replace(/^ffmpeg version /, 'version ')})` : ''}`
    : 'Not found. Install it with “winget install Gyan.FFmpeg” or choose ffmpeg.exe.';
  const descEl = h('span', { class: `setting-desc${info && !info.ffmpegPath ? ' error' : ''}` }, desc);
  replace(els.ffmpeg, settingRow({ iconName: 'wrench_20_regular', label: 'FFmpeg (does the video encoding)', desc: descEl,
    control: [h('fluent-button', { onclick: pickFfmpeg }, 'Choose…'),
      custom ? h('fluent-button', { appearance: 'subtle', onclick: () => save('ffmpeg_path', '').then(load) }, 'Use automatic') : null] }));
}

function syncAll() {
  for (const fn of sync.values()) fn();
  els.startup.checked = !!ctx.state.startup;
  renderRecordingNotice();
  renderReplayStatus();
}

function renderRecordingNotice() {
  if (!ctx.isRecording()) { replace(els.notice); return; }
  if (els.notice.firstChild) return;
  replace(els.notice, h('fluent-message-bar', { intent: 'info', shape: 'rounded', layout: 'multiline' },
    Object.assign(icon('info_20_filled'), { slot: 'icon' }),
    'You’re recording. Changes to recording and sound settings apply to your next recording.'));
}

async function pickFolder() {
  try {
    const picked = await ctx.call('folder.pick');
    if (picked) await save('output_folder', picked);
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function pickFfmpeg() {
  try {
    const picked = await ctx.call('ffmpeg.pick');
    if (picked && await save('ffmpeg_path', picked)) await load();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function resetAll() {
  const ok = await confirmDialog({
    title: 'Reset all settings?',
    text: 'All settings go back to how they were when FullRecorder was installed, including the save folder and shortcuts. Your recordings are not touched.',
    ok: 'Reset',
    danger: true,
  });
  if (!ok) return;
  try {
    const { values } = await ctx.call('settings.reset');
    ctx.state.settings = values;
    ctx.publish('settings');
    toast('Settings were reset.', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}
