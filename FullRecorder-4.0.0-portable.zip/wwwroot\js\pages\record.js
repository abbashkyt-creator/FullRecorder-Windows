// Record page: start/pause/stop, live status, what will be recorded, where it goes, latest recording.
import { h, icon, startIcon, replace, keycaps, formatClock, formatBytes, formatDuration, formatDate, toast } from '../dom.js';

let ctx, root;
let els = {};
let devices = null;
let windows = { picked: 0, windows: [] };
let latest = null;
let freeGb = null;
let ffmpegMissing = false;
let ffmpegTimer = null;
let pageVisible = false;
let actionsKey = '';     // what the Pause/Stop buttons show; they are rebuilt only when it changes

const MODES = [
  { value: 'screen', label: 'Whole screen', iconName: 'desktop_20_regular' },
  { value: 'window', label: 'One window', iconName: 'window_20_regular' },
  { value: 'region', label: 'An area', iconName: 'select_object_20_regular' },
];

export function mount(section, context) {
  ctx = context;
  root = section;
  build();
  ctx.subscribe('status', renderStatus);
  ctx.subscribe('settings', () => { renderStatus(); renderCapture(); renderTiles(); renderFolder(); renderReplay(); });
  ctx.subscribe('recordings', loadLatest);
  ctx.subscribe('replay', renderReplay);
  loadDevices();
  loadLatest();
}

export function shown() {
  pageVisible = true;
  loadLatest();
  if (ctx.state.settings.capture_mode === 'window') loadWindows();
  checkFfmpeg();
}

export function hidden() {
  pageVisible = false;
  clearInterval(ffmpegTimer);
  ffmpegTimer = null;
}

function build() {
  els.setup = h('div');
  els.problem = h('div');
  els.warnings = h('div', { class: 'stack' });
  els.replay = h('div');
  els.button = h('button', { class: 'record-button', type: 'button', onclick: onRecordClick }, h('span', { class: 'record-glyph', 'aria-hidden': 'true' }));
  els.title = h('div', { class: 'hero-title', id: 'record-title' });
  els.desc = h('p', { class: 'hero-desc' });
  els.meters = h('div', { class: 'meters', hidden: true },
    meter('speaker_2_20_regular', 'System sound', 'sys'),
    meter('mic_20_regular', 'Microphone', 'mic'));
  els.actions = h('div', { class: 'hero-actions' });

  els.modes = h('fluent-radio-group', { class: 'mode-group', orientation: 'horizontal', 'aria-labelledby': 'capture-title', name: 'capture-mode' },
    MODES.map((m) => h('fluent-field', { 'label-position': 'after' },
      h('label', { slot: 'label', for: `mode-${m.value}` }, icon(m.iconName), m.label),
      h('fluent-radio', { slot: 'input', id: `mode-${m.value}`, name: 'capture-mode', value: m.value }))));
  els.modes.addEventListener('change', onModeChange);
  els.captureDetail = h('div', { class: 'capture-detail' });
  els.tiles = h('div', { class: 'tiles two' });
  els.folder = h('div', { class: 'card row-card' });
  els.latest = h('div');

  replace(root,
    h('div', { class: 'page-header' }, h('h1', { id: 'h-record', tabindex: '-1' }, 'Record')),
    h('p', { class: 'page-sub' }, 'Your screen, everything you hear and your microphone, saved together in one video.'),
    els.setup,
    els.problem,
    els.warnings,
    h('div', { class: 'card hero', role: 'group', 'aria-labelledby': 'record-title' },
      els.button,
      h('div', {}, els.title, els.desc, els.meters, els.actions)),
    els.replay,
    h('h2', { class: 'section-title', id: 'capture-title' }, 'What to record'),
    h('div', { class: 'card capture-card' }, els.modes, els.captureDetail),
    els.tiles,
    h('h2', { class: 'section-title' }, 'Saved to'),
    els.folder,
    h('h2', { class: 'section-title' }, 'Latest recording'),
    els.latest,
  );
  renderStatus();
  renderCapture();
  renderTiles();
  renderFolder();
  renderLatest();
  renderReplay();
}

// ---------------------------------------------------------------- instant replay

let replayKey = '';
function renderReplay() {
  const s = ctx.state.settings;
  const r = ctx.state.replay ?? { state: 'off' };
  if (!s.replay_enabled) { replayKey = ''; replace(els.replay); return; }
  const running = r.state === 'running';
  const ready = running && r.bufferedSeconds >= 1; // something to save
  const text = running
    ? `Instant replay is keeping the last ${formatDuration(r.seconds)} (${formatDuration(r.bufferedSeconds)} so far).`
    : r.state === 'waitingforpower' ? 'Instant replay is waiting: the PC is on battery.'
      : r.state === 'failed' ? `Instant replay couldn’t start: ${r.error ?? ''}` : 'Instant replay is starting…';
  // The button is rebuilt only when it changes (the text updates every second).
  const key = `${ready}|${s.replay_hotkey}`;
  if (key !== replayKey || !els.replayText) {
    replayKey = key;
    els.replayText = h('span', { class: 'grow' });
    replace(els.replay, h('div', { class: 'card row-card replay-card' },
      icon('replay_20_regular'),
      els.replayText,
      s.replay_hotkey ? h('span', { class: 'shortcut-hint' }, keycaps(s.replay_hotkey)) : null,
      h('fluent-button', { appearance: 'primary', disabled: !ready, onclick: saveReplay }, startIcon('save_20_regular'), 'Save replay')));
  }
  els.replayText.textContent = text;
}

async function saveReplay(e) {
  const btn = e.currentTarget;
  btn.disabled = true;
  try {
    await ctx.call('replay.save'); // the app then announces the file (the "saved" event, as for recordings)
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = !(ctx.state.replay?.state === 'running' && ctx.state.replay.bufferedSeconds >= 1);
  }
}

function meter(iconName, label, key) {
  const fill = h('div', { class: 'meter-fill' });
  els[`meter-${key}`] = fill;
  return h('div', { class: 'meter' }, icon(iconName),
    h('span', {}, label),
    h('div', { class: 'meter-track', role: 'meter', 'aria-label': `${label} level`, 'aria-valuemin': '0', 'aria-valuemax': '100' }, fill));
}

function shortcuts() {
  const s = ctx.state.settings;
  return { start: s.start_hotkey || s.toggle_hotkey, stop: s.stop_hotkey || s.toggle_hotkey, pause: s.pause_hotkey };
}

// ---------------------------------------------------------------- status

function renderStatus() {
  const st = ctx.state.status;
  const { start, stop, pause } = shortcuts();
  const busy = ['starting', 'stopping', 'pausing', 'resuming'].includes(st.state);
  const recording = st.state === 'recording';
  const paused = st.state === 'paused';

  els.button.dataset.state = paused ? 'recording' : st.state;
  els.button.disabled = busy;
  els.button.setAttribute('aria-label', recording || paused ? 'Stop and save the recording'
    : busy ? ({ starting: 'Starting', pausing: 'Pausing', resuming: 'Resuming', stopping: 'Saving' })[st.state]
      : 'Start recording');
  // Only when it changes: replacing what's under the pointer 4 times a second can swallow a click.
  const content = busy ? 'spinner' : 'glyph';
  if (els.button.dataset.content !== content) {
    els.button.dataset.content = content;
    replace(els.button, busy
      ? h('fluent-spinner', { size: 'medium', 'aria-hidden': 'true' })
      : h('span', { class: 'record-glyph', 'aria-hidden': 'true' }));
  }

  if (recording || paused || st.state === 'pausing') {
    replace(els.title,
      paused ? icon('pause_20_filled', 'icon paused-icon') : h('span', { class: 'rec-dot', 'aria-hidden': 'true' }),
      h('span', { class: 'hero-timer' }, formatClock(st.elapsedSeconds)),
      paused ? h('fluent-badge', { appearance: 'tint', color: 'warning', shape: 'rounded' }, 'Paused') : null);
    replace(els.desc, paused ? 'Nothing is being recorded until you resume.' : `Recording ${st.target ?? ''} · ${formatBytes(st.bytes)} so far`,
      st.method && !paused ? ` · ${st.method}` : '');
  } else if (st.state === 'starting' || st.state === 'resuming') {
    replace(els.title, st.state === 'starting' ? 'Starting…' : 'Resuming…');
    replace(els.desc, 'Getting the screen and sound ready. This takes a moment, especially when the graphics card has been idle.');
  } else if (st.state === 'stopping') {
    replace(els.title, 'Saving…');
    replace(els.desc, 'Finishing the video file.');
  } else {
    replace(els.title, 'Ready to record');
    replace(els.desc,
      start ? h('span', {}, 'Press ', keycaps(start), ' anywhere, or select the button. ') : 'Select the button to start. ',
      ctx.state.settings.hide_window_on_record ? 'This window gets out of the way while you record.' : '');
  }

  els.meters.hidden = !recording;
  if (recording) {
    setMeter('sys', st.systemLevel, ctx.state.settings.system_audio);
    setMeter('mic', st.microphoneLevel, ctx.state.settings.microphone);
  }

  // Rebuilt only when something on them changes: status arrives 4 times a second, and
  // re-creating the buttons would swallow clicks and move keyboard focus away.
  const key = `${recording || paused ? st.state : ''}|${pause}|${stop}`;
  if (key !== actionsKey) {
    actionsKey = key;
    renderActions(recording, paused, stop, pause);
  }

  renderWarnings();
  renderProblem();
  const locked = ctx.isRecording();
  if (els.modes.hasAttribute('disabled') !== locked) {
    els.modes.toggleAttribute('disabled', locked);
    renderCapture();
  }
}

function renderActions(recording, paused, stop, pause) {
  replace(els.actions);
  if (recording || paused) {
    els.actions.append(
      h('fluent-button', { appearance: paused ? 'primary' : 'secondary', onclick: () => ctx.call('recorder.pause').catch((e) => toast(e.message, 'error')) },
        startIcon(paused ? 'record_20_filled' : 'pause_20_filled'), paused ? 'Resume' : 'Pause'),
      h('fluent-button', { appearance: paused ? 'secondary' : 'primary', onclick: () => ctx.call('recorder.stop') }, startIcon('stop_20_filled'), 'Stop and save'),
      pause || stop ? h('span', { class: 'shortcut-hint' },
        pause ? [keycaps(pause), paused ? ' resumes' : ' pauses'] : null,
        pause && stop ? h('span', { 'aria-hidden': 'true' }, '·') : null,
        stop ? [keycaps(stop), ' stops'] : null) : null);
  }
}

/** Peak (0..1) to a meter position using a -60..0 dB scale, like Windows' own meters. */
function setMeter(key, peak, enabled) {
  const db = peak > 0 ? 20 * Math.log10(peak) : -60;
  const pos = enabled ? Math.max(0, Math.min(1, (db + 60) / 60)) : 0;
  const fill = els[`meter-${key}`];
  fill.style.transform = `scaleX(${pos})`;
  fill.parentElement.setAttribute('aria-valuenow', String(Math.round(pos * 100)));
}

let warningKey = '';
function renderWarnings() {
  const list = ctx.isRecording() ? (ctx.state.status.warnings ?? []) : [];
  const key = list.join('|');
  if (key === warningKey) return;
  warningKey = key;
  replace(els.warnings, list.map((w) => h('fluent-message-bar', { intent: 'warning', layout: 'multiline', shape: 'rounded' },
    Object.assign(icon('warning_20_filled'), { slot: 'icon' }), w)));
}

function renderProblem() {
  const err = ctx.state.status.lastError;
  if (!err || ctx.state.status.state !== 'idle') { replace(els.problem); return; }
  replace(els.problem, h('fluent-message-bar', { intent: 'error', layout: 'multiline', shape: 'rounded' },
    Object.assign(icon('error_circle_20_filled'), { slot: 'icon' }),
    err));
}

async function onRecordClick() {
  try {
    const state = ctx.state.status.state;
    await ctx.call(state === 'recording' || state === 'paused' ? 'recorder.stop' : 'recorder.start');
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ---------------------------------------------------------------- ffmpeg setup

async function checkFfmpeg() {
  try {
    const { path } = await ctx.call('ffmpeg.check');
    const missing = !path;
    if (missing !== ffmpegMissing) {
      ffmpegMissing = missing;
      if (!missing) toast('FFmpeg is ready. You can record now.', 'success');
    }
  } catch {
    // keep the last answer
  }
  renderSetup();
  clearInterval(ffmpegTimer);
  ffmpegTimer = ffmpegMissing && pageVisible ? setInterval(checkFfmpeg, 5000) : null;
}

async function installFfmpeg(btn) {
  btn.disabled = true; // one installer window at a time
  try {
    await ctx.call('ffmpeg.install');
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    setTimeout(() => { btn.disabled = false; }, 4000);
  }
}

function renderSetup() {
  if (!ffmpegMissing) { replace(els.setup); return; }
  replace(els.setup, h('fluent-message-bar', { intent: 'warning', layout: 'multiline', shape: 'rounded' },
    Object.assign(icon('warning_20_filled'), { slot: 'icon' }),
    h('span', {}, h('strong', {}, 'One more step: FullRecorder needs FFmpeg. '),
      'It’s the free video encoder FullRecorder uses. Install it with Windows’ own package manager (a window opens; FullRecorder notices when it’s done), or choose ffmpeg.exe if you already have it.'),
    h('fluent-button', { slot: 'actions', appearance: 'primary', size: 'small', onclick: (e) => installFfmpeg(e.currentTarget) },
      startIcon('arrow_download_20_regular'), 'Install FFmpeg'),
    h('fluent-button', { slot: 'actions', size: 'small', onclick: pickFfmpeg }, 'Choose ffmpeg.exe…')));
}

async function pickFfmpeg() {
  try {
    const picked = await ctx.call('ffmpeg.pick');
    if (picked) {
      await ctx.setSetting('ffmpeg_path', picked);
      checkFfmpeg();
    }
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ---------------------------------------------------------------- what to record

async function loadDevices() {
  try {
    devices = await ctx.call('devices.list');
  } catch {
    devices = null;
  }
  renderCapture();
  renderTiles();
}

async function loadWindows() {
  try {
    windows = await ctx.call('capture.windows');
  } catch {
    windows = { picked: 0, windows: [] };
  }
  renderCapture();
}

async function onModeChange() {
  const mode = els.modes.value;
  if (!mode || mode === ctx.state.settings.capture_mode) return;
  try {
    // Choosing "An area" shows its "Select area…" button; the screen isn't frozen just because
    // the arrow keys passed over the option.
    await ctx.setSetting('capture_mode', mode);
    if (mode === 'window') loadWindows();
  } catch (err) {
    toast(err.message, 'error');
    renderCapture();
  }
}

async function selectArea() {
  try {
    const r = await ctx.call('capture.selectRegion');
    if (r) {
      ctx.state.settings = r.values;
      ctx.publish('settings');
    }
  } catch (err) {
    toast(err.message, 'error');
  }
}

function regionText(region) {
  const [x, y, w, hh] = (region || '').split(',').map(Number);
  if (!w) return null;
  return `${w & ~1} × ${hh & ~1} pixels, starting ${x}, ${y} from the top-left of the screen`;
}

function renderCapture() {
  const s = ctx.state.settings;
  const mode = s.capture_mode || 'screen';
  requestAnimationFrame(() => { if (els.modes.value !== mode) els.modes.value = mode; });
  const { start } = shortcuts();

  if (mode === 'window') {
    const dd = h('fluent-dropdown', { 'aria-label': 'Window to record', appearance: 'outline', class: 'window-picker' },
      h('fluent-listbox', {},
        h('fluent-option', { value: '0' }, start ? `The window I’m using when I press ${start}` : 'The window I’m using when I start'),
        windows.windows.map((w) => h('fluent-option', { value: String(w.handle) },
          `${w.title}${w.app && !w.title.includes(w.app) ? ` — ${w.app}` : ''}${w.minimized ? ' (minimized)' : ''}`))));
    dd.addEventListener('change', () => {
      windows.picked = Number(dd.value) || 0;
      ctx.call('capture.pickWindow', { handle: windows.picked }).catch((e) => toast(e.message, 'error'));
    });
    requestAnimationFrame(() => { dd.value = String(windows.picked || 0); });
    const appOnly = s.window_audio === 'app' && s.system_audio;
    replace(els.captureDetail,
      h('div', { class: 'capture-row' }, dd,
        h('fluent-button', { appearance: 'subtle', 'icon-only': true, 'aria-label': 'Refresh the list of windows', title: 'Refresh', onclick: loadWindows },
          icon('arrow_clockwise_20_regular'))),
      h('p', { class: 'capture-note' },
        'Only that window is recorded, even when other windows cover it. If it’s resized, the picture is scaled to fit. Closing the window ends the recording. ',
        appOnly ? 'Only that app’s sound is recorded (change this in Settings).' : 'System sound from all apps is recorded (you can limit it to that app in Settings).'));
  } else if (mode === 'region') {
    const text = regionText(s.region);
    replace(els.captureDetail,
      h('div', { class: 'capture-row' },
        h('div', { class: 'grow' },
          h('span', {}, text ? 'Selected area' : 'No area selected yet'),
          h('span', { class: 'muted small' }, text ?? 'Draw the part of the screen you want to record.')),
        h('fluent-button', { appearance: text ? 'secondary' : 'primary', onclick: selectArea, disabled: ctx.isRecording() },
          startIcon('select_object_20_regular'), text ? 'Select again…' : 'Select area…')),
      h('p', { class: 'capture-note' }, 'A thin red frame shows the area while you record; it never appears in the video.'));
  } else {
    const list = devices?.displays ?? [];
    const display = list.find((d) => d.index === s.monitor) ?? list[0];
    const label = display ? `${display.name} · ${display.width} × ${display.height}` : 'Main screen';
    let control = h('span', { class: 'muted' }, label);
    if (list.length > 1) {
      control = h('fluent-dropdown', { 'aria-label': 'Screen to record', appearance: 'outline' },
        h('fluent-listbox', {}, list.map((d) => h('fluent-option', { value: String(d.index) }, `${d.name} · ${d.width} × ${d.height}`))));
      control.addEventListener('change', () => ctx.setSetting('monitor', Number(control.value)).catch((e) => toast(e.message, 'error')));
      requestAnimationFrame(() => { control.value = String(display?.index ?? 0); });
    }
    replace(els.captureDetail,
      h('div', { class: 'capture-row' }, control),
      h('p', { class: 'capture-note' }, 'Everything on the screen, except FullRecorder’s own window.'));
  }
}

// ---------------------------------------------------------------- sound

function deviceName(list, chosen) {
  if (chosen) return list?.find((d) => d.name.toLowerCase().includes(chosen.toLowerCase()))?.name ?? chosen;
  return list?.find((d) => d.isDefault)?.name ?? 'Windows default';
}

function systemSoundText(s) {
  if (!s.system_audio) return 'Off';
  if (s.capture_mode === 'window' && s.window_audio === 'app' && !s.system_device) return 'Only the recorded app';
  const name = deviceName(devices?.speakers, s.system_device);
  return s.exclude_own_sounds && !s.system_device ? `${name} · without FullRecorder’s beeps` : name;
}

function renderTiles() {
  const s = ctx.state.settings;
  replace(els.tiles,
    tile('speaker_2_20_regular', 'System sound', systemSoundText(s), toggle('system_audio', 'Record system sound'), !s.system_audio),
    tile('mic_20_regular', 'Microphone',
      s.microphone ? deviceName(devices?.microphones, s.microphone_device) : 'Off',
      toggle('microphone', 'Record the microphone'),
      !s.microphone),
  );
}

function tile(iconName, title, body, control, off) {
  return h('div', { class: 'card tile', dataset: { off: String(off) } },
    h('div', { class: 'tile-head' }, h('span', { class: 'tile-title' }, icon(iconName), title), control),
    h('div', { class: 'tile-body', title: body }, body));
}

function toggle(key, label) {
  const sw = h('fluent-switch', { checked: !!ctx.state.settings[key], 'aria-label': label });
  sw.addEventListener('change', async () => {
    try {
      await ctx.setSetting(key, sw.checked);
      if (ctx.isRecording()) toast('This applies to your next recording.', 'info');
    } catch (err) {
      sw.checked = !!ctx.state.settings[key];
      toast(err.message, 'error');
    }
  });
  return sw;
}

// ---------------------------------------------------------------- folder & latest

function renderFolder() {
  const path = ctx.state.settings.output_folder ?? '';
  replace(els.folder,
    icon('folder_open_20_regular'),
    h('div', { class: 'grow' },
      h('span', { class: 'path', title: path }, path),
      h('span', { class: 'muted small' }, freeGb != null ? `${freeGb.toFixed(freeGb < 10 ? 1 : 0)} GB free` : '')),
    h('fluent-button', { onclick: () => ctx.call('folder.open').catch((e) => toast(e.message, 'error')) }, 'Open folder'),
    h('fluent-button', { appearance: 'subtle', onclick: changeFolder }, 'Change…'));
}

async function changeFolder() {
  try {
    const picked = await ctx.call('folder.pick');
    if (picked) {
      await ctx.setSetting('output_folder', picked);
      toast('Recordings will be saved to the new folder.', 'success');
    }
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadLatest() {
  try {
    const list = await ctx.call('recordings.list');
    latest = list.items.find((r) => !r.unfinished) ?? null;
    freeGb = list.freeGb;
  } catch {
    latest = null;
  }
  renderLatest();
  renderFolder();
}

function renderLatest() {
  if (!latest) {
    replace(els.latest, h('div', { class: 'card row-card' }, icon('video_clip_20_regular'),
      h('div', { class: 'grow' }, h('span', {}, 'No recordings yet'),
        h('span', { class: 'muted small' }, 'Your recordings will appear here and on the Recordings page.'))));
    return;
  }
  const r = latest;
  replace(els.latest, h('div', { class: 'card latest' },
    h('div', { class: 'thumb' }, r.thumbnail ? h('img', { src: r.thumbnail, alt: '' }) : icon('video_20_regular', 'icon icon-24'),
      r.durationSeconds ? h('span', { class: 'duration-badge' }, formatDuration(r.durationSeconds)) : null),
    h('div', { style: 'min-width:0' },
      h('div', { class: 'latest-title', title: r.name }, r.name),
      h('div', { class: 'muted small' }, `${formatDate(r.modified)} · ${formatBytes(r.bytes)}`)),
    h('div', { class: 'latest-actions', style: 'display:flex; gap: var(--spacingHorizontalS)' },
      h('fluent-button', { appearance: 'primary', onclick: () => ctx.call('recordings.play', { path: r.path }).catch((e) => toast(e.message, 'error')) },
        startIcon('play_20_filled'), 'Play'),
      h('fluent-button', { onclick: () => ctx.openEditor?.(r) }, startIcon('cut_20_regular'), 'Trim'),
      h('fluent-button', { appearance: 'subtle', onclick: () => ctx.go('recordings') }, 'All recordings'))));
}
