// Design-preview stand-in for the app, used only when the page is opened in a normal
// browser. Never loaded inside FullRecorder.

let emit = () => {};
let attached = false;
let ticker = null;

const now = Date.now();
const settings = {
  output_folder: 'D:\\Movies D\\Claude Record', file_name: 'Recording_{date}_{time}', container: 'mp4', fps: 30,
  monitor: 0, capture_cursor: true, quality: 23, encoder: 'auto', hide_from_capture: true, hide_window_on_record: true,
  system_audio: true, microphone: true, system_volume: 1, microphone_volume: 1, system_device: '', microphone_device: '',
  separate_tracks: false, system_audio_offset_ms: 0, audio_bitrate_kbps: 192, exclude_own_sounds: true, window_audio: 'all',
  video_codec: 'h264', capture_mode: 'screen', region: '',
  toggle_hotkey: '', start_hotkey: 'Ctrl+Shift+G', stop_hotkey: 'Ctrl+Shift+J', pause_hotkey: 'Ctrl+Alt+P', replay_hotkey: 'Ctrl+Alt+F10',
  quit_hotkey: 'Ctrl+Alt+Shift+Q',
  replay_enabled: true, replay_seconds: 120, replay_on_battery: false,
  webcam: 'off', webcam_device: '', webcam_size: 'medium', webcam_mirror: true, webcam_position: '', click_highlights: false,
  tray_icon: true, notify_saved: true, sounds: true, sound_volume: 0.3, theme: 'system',
  ffmpeg_path: '', min_free_space_gb: 2,
};
const recordingKeys = ['output_folder', 'file_name', 'container', 'fps', 'monitor', 'capture_cursor', 'quality', 'encoder',
  'system_audio', 'microphone', 'system_volume', 'microphone_volume', 'system_device', 'microphone_device',
  'separate_tracks', 'system_audio_offset_ms', 'audio_bitrate_kbps', 'ffmpeg_path',
  'video_codec', 'capture_mode', 'exclude_own_sounds', 'window_audio'];

function thumb(hue) {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 160 90'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='hsl(${hue} 60% 55%)'/><stop offset='1' stop-color='hsl(${hue + 40} 55% 30%)'/></linearGradient></defs><rect width='160' height='90' fill='url(%23g)'/><rect x='10' y='10' width='60' height='8' rx='2' fill='white' opacity='.5'/><rect x='10' y='24' width='100' height='40' rx='3' fill='white' opacity='.18'/></svg>`;
  return `data:image/svg+xml;utf8,${svg.replace(/#/g, '%23')}`;
}

let items = [
  { name: 'Recording_2026-10-22_18-40-12.mp4', minutesAgo: 3, dur: 754, mb: 212, hue: 210 },
  { name: 'Team call notes.mp4', minutesAgo: 95, dur: 2711, mb: 640, hue: 280 },
  { name: 'Recording_2026-10-21_21-03-55.mp4', minutesAgo: 1300, dur: 64, mb: 18.4, hue: 20 },
  { name: 'Bug repro - auction page.mp4', minutesAgo: 2900, dur: 191, mb: 47, hue: 150 },
  { name: 'Recording_2026-10-19_09-12-01.mkv', minutesAgo: 5000, dur: null, mb: 1240, hue: 330 },
].map((r) => ({
  path: `D:\\Movies D\\Claude Record\\${r.name}`, name: r.name, bytes: Math.round(r.mb * 1048576),
  modified: new Date(now - r.minutesAgo * 60000).toISOString(), durationSeconds: r.dur, thumbnail: r.dur ? thumb(r.hue) : null,
  unfinished: false, parts: 1,
}));
items.splice(2, 0, {
  path: 'D:\\Movies D\\Claude Record\\Recording_2026-10-22_11-20-05.recording.mkv', name: 'Recording_2026-10-22_11-20-05.mp4',
  bytes: 96 * 1048576, modified: new Date(now - 600 * 60000).toISOString(), durationSeconds: null, thumbnail: thumb(60),
  unfinished: true, parts: 2,
});

const windowList = [
  { handle: 132456, title: 'Bug repro - Auction admin - Microsoft Edge', app: 'Microsoft Edge', minimized: false },
  { handle: 198722, title: 'Program.cs - FullRecorder - Visual Studio Code', app: 'Visual Studio Code', minimized: false },
  { handle: 245810, title: 'Team call', app: 'Microsoft Teams', minimized: true },
];
let pickedWindow = 0;
const jobs = new Map();

const status = {
  state: 'idle', elapsedSeconds: 0, bytes: 0, file: null, systemLevel: 0, microphoneLevel: 0,
  systemDevice: null, microphoneDevice: null, method: null, target: null, warnings: [], lastSaved: items[0].path, lastError: null,
};
let pausedFor = 0;
const replayStarted = Date.now();
const replay = () => ({
  state: settings.replay_enabled ? 'running' : 'off', seconds: settings.replay_seconds,
  bufferedSeconds: Math.min(settings.replay_seconds, (Date.now() - replayStarted) / 1000), error: null,
});
setInterval(() => emit('replay', replay()), 1000);
let pausedAt = 0;
let startedAt = 0;

export function attach(receive) {
  if (attached) return;
  attached = true;
  emit = (event, data) => setTimeout(() => receive({ event, data }), 0);
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export async function call(method, params, receive) {
  attach(receive);
  await wait(60);
  switch (method) {
    case 'app.init':
      return { settings: { ...settings }, recordingKeys, status: { ...status }, startup: true, version: '4.0.0', hotkeyErrors: {}, appSoundSupported: true, replay: replay() };
    case 'app.info':
      return {
        version: '4.0.0', ffmpegPath: 'C:\\Users\\you\\AppData\\Local\\Microsoft\\WinGet\\Links\\ffmpeg.exe',
        ffmpegVersion: 'ffmpeg version 8.1.1-full_build-www.gyan.dev', webViewVersion: '155.0.3400.25',
        windows: 'Microsoft Windows NT 10.0.26200.0', settingsFile: 'C:\\Users\\you\\AppData\\Roaming\\FullRecorder\\FullRecorder.ini',
        logFile: 'C:\\Users\\you\\AppData\\Local\\FullRecorder\\FullRecorder.log', dataFolder: 'C:\\Users\\you\\AppData\\Local\\FullRecorder',
      };
    case 'settings.set': {
      const { key, value } = params;
      if (key.endsWith('_hotkey') && value && Object.entries(settings).some(([k, v]) => k !== key && k.endsWith('_hotkey') && v === value))
        throw new Error(`${value} is already used for another FullRecorder shortcut.`);
      settings[key] = value;
      return { values: { ...settings } };
    }
    case 'settings.reset': return { values: { ...settings } };
    case 'startup.set': return { enabled: params.enabled };
    case 'devices.list':
      return {
        speakers: [{ name: 'Speakers (Realtek(R) Audio)', isDefault: true }, { name: 'Headphones (WH-1000XM4)', isDefault: false }],
        microphones: [{ name: 'Microphone Array (Realtek(R) Audio)', isDefault: true }],
        displays: [{ index: 0, name: 'Display 1 (main)', width: 1920, height: 1080, primary: true }],
      };
    case 'hotkeys.capture': return null;
    case 'hotkeys.check': return { ok: true, normalized: params.spec, error: null };
    case 'recorder.status': return { ...status };
    case 'replay.status': return replay();
    case 'replay.save': {
      await wait(700);
      const name = `Replay_${new Date().toISOString().slice(0, 19).replace('T', '_').replace(/:/g, '-')}.mp4`;
      const r = replay();
      items = [{ path: `D:\\Movies D\\Claude Record\\${name}`, name, bytes: 31 * 1048576, modified: new Date().toISOString(),
        durationSeconds: r.bufferedSeconds, thumbnail: thumb(40), unfinished: false, parts: 1 }, ...items];
      emit('saved', { path: items[0].path, notes: [] }); // as the app does
      return { path: items[0].path };
    }
    case 'cameras.list': await wait(300); return { cameras: ['Integrated Camera', 'OBS Virtual Camera'] };
    case 'capture.windows': return { picked: pickedWindow, windows: windowList.map((w) => ({ ...w })) };
    case 'capture.pickWindow': pickedWindow = params.handle; return null;
    case 'capture.selectRegion':
      await wait(400);
      settings.region = '320,180,1281,721';
      return { region: settings.region, values: { ...settings } };
    case 'recorder.pause':
      if (status.state === 'recording') {
        status.state = 'pausing'; emit('status', { ...status }); await wait(500);
        status.state = 'paused'; pausedAt = Date.now();
      } else if (status.state === 'paused') {
        status.state = 'resuming'; emit('status', { ...status }); await wait(900);
        pausedFor += Date.now() - pausedAt; status.state = 'recording';
      }
      emit('status', { ...status });
      return null;
    case 'ffmpeg.check': return { path: 'C:\\Users\\you\\AppData\\Local\\Microsoft\\WinGet\\Links\\ffmpeg.exe' };
    case 'ffmpeg.install': return null;
    case 'recordings.media': throw new Error('No preview in the design preview.');
    case 'recordings.trim':
    case 'recordings.gif': {
      jobs.set(params.job, false);
      for (let i = 1; i <= 10; i++) {
        await wait(150);
        if (jobs.get(params.job)) { jobs.delete(params.job); throw new Error('Cancelled.'); }
        emit('job', { id: params.job, progress: i / 10 });
      }
      jobs.delete(params.job);
      const src = items.find((x) => x.path === params.path);
      const base = src.name.replace(/\.[^.]+$/, '');
      const name = method === 'recordings.gif' ? `${base}.gif` : `${base} (trimmed).mp4`;
      if (method === 'recordings.trim') {
        items = [{ ...src, name, path: `D:\\Movies D\\Claude Record\\${name}`, durationSeconds: params.end - params.start, modified: new Date().toISOString() }, ...items];
        emit('recordings', null);
      }
      return { path: `D:\\Movies D\\Claude Record\\${name}` };
    }
    case 'jobs.cancel': jobs.set(params.job, true); return null;
    case 'recordings.recover': {
      await wait(700);
      const it = items.find((x) => x.path === params.path);
      Object.assign(it, { unfinished: false, parts: 1, durationSeconds: 1234, path: `D:\\Movies D\\Claude Record\\${it.name}` });
      emit('recordings', null);
      return { path: it.path };
    }
    case 'recorder.start':
      status.state = 'starting'; emit('status', { ...status });
      await wait(1200);
      status.state = 'recording'; startedAt = Date.now(); pausedFor = 0;
      status.target = settings.capture_mode === 'window' ? 'the window "Bug repro - Auction admin"' : settings.capture_mode === 'region' ? 'an area of screen 1 (1280 × 720)' : 'screen 1 (1920 × 1080)';
      status.file = 'D:\\Movies D\\Claude Record\\Recording_2026-10-22_19-02-44.mp4';
      status.systemDevice = 'Speakers (Realtek(R) Audio)'; status.microphoneDevice = 'Microphone Array (Realtek(R) Audio)';
      status.method = 'NVIDIA encoder, Windows Graphics Capture (zero-copy)';
      ticker = setInterval(() => {
        if (status.state !== 'recording') return;
        status.elapsedSeconds = (Date.now() - startedAt - pausedFor) / 1000;
        status.bytes = status.elapsedSeconds * 260000;
        status.systemLevel = Math.max(0, Math.min(1, 0.35 + Math.sin(Date.now() / 300) * 0.25 + Math.random() * 0.2));
        status.microphoneLevel = Math.random() < 0.4 ? Math.random() * 0.7 : 0.03;
        emit('status', { ...status });
      }, 250);
      emit('status', { ...status });
      return null;
    case 'recorder.stop': {
      clearInterval(ticker);
      status.state = 'stopping'; emit('status', { ...status });
      await wait(900);
      const saved = {
        path: status.file, name: status.file.split('\\').pop(), bytes: status.bytes, modified: new Date().toISOString(),
        durationSeconds: status.elapsedSeconds, thumbnail: thumb(190), unfinished: false, parts: 1,
      };
      items = [saved, ...items];
      Object.assign(status, { state: 'idle', elapsedSeconds: 0, bytes: 0, systemLevel: 0, microphoneLevel: 0, lastSaved: saved.path });
      emit('status', { ...status });
      emit('saved', { path: saved.path, notes: [] });
      emit('recordings', null);
      return null;
    }
    case 'recordings.list': return { folder: settings.output_folder, freeGb: 742.3, items: items.map((i) => ({ ...i })) };
    case 'recordings.rename': {
      const it = items.find((i) => i.path === params.path);
      const ext = it.name.slice(it.name.lastIndexOf('.'));
      it.name = params.name.endsWith(ext) ? params.name : params.name + ext;
      it.path = `D:\\Movies D\\Claude Record\\${it.name}`;
      emit('recordings', null);
      return { path: it.path };
    }
    case 'recordings.delete':
      items = items.filter((i) => i.path !== params.path);
      emit('recordings', null);
      return null;
    case 'folder.pick': return 'D:\\Videos\\Screen recordings';
    case 'ffmpeg.pick': return null;
    default: return null;
  }
}
