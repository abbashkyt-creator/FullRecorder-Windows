// Small DOM, formatting and feedback helpers shared by the pages.
import { icons } from '../vendor/icons.js';

/**
 * Creates an element. Text children are inserted as text (never parsed as HTML), so
 * file names and other user data are always safe.
 *   h('div', { class: 'x', onclick: fn }, 'text', otherNode)
 */
export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs ?? {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k in el && typeof v !== 'string') el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

/** A Fluent System Icon (decorative; give the parent an accessible name). */
export function icon(name, cls = 'icon') {
  const span = document.createElement('span');
  span.className = cls;
  span.setAttribute('aria-hidden', 'true');
  span.innerHTML = icons[name] ?? ''; // trusted, generated at build time
  return span;
}

/** An icon for a Fluent button's "start" slot. */
export function startIcon(name) {
  const i = icon(name);
  i.slot = 'start';
  return i;
}

/** Fills elements marked data-icon="name" in static markup. */
export function hydrateIcons(root = document) {
  for (const el of root.querySelectorAll('[data-icon]')) {
    if (!el.firstChild) el.innerHTML = icons[el.dataset.icon] ?? '';
  }
}

export function replace(el, ...children) {
  el.replaceChildren();
  append(el, children);
}

// ---------------------------------------------------------------- formatting

export function formatDuration(seconds) {
  if (seconds == null || !isFinite(seconds)) return '';
  const s = Math.floor(seconds);
  const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
  const two = (n) => String(n).padStart(2, '0');
  return hh > 0 ? `${hh}:${two(mm)}:${two(ss)}` : `${mm}:${two(ss)}`;
}

export function formatClock(seconds) {
  const s = Math.max(0, Math.floor(seconds ?? 0));
  const two = (n) => String(n).padStart(2, '0');
  return `${two(Math.floor(s / 3600))}:${two(Math.floor((s % 3600) / 60))}:${two(s % 60)}`;
}

export function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  const mb = bytes / 1048576;
  if (mb < 1024) return `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB`;
  return `${(mb / 1024).toFixed(mb < 10240 ? 2 : 1)} GB`;
}

const dateFmt = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' });
const relFmt = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });

export function formatDate(iso) {
  const d = new Date(iso);
  const diffMin = (Date.now() - d.getTime()) / 60000;
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return relFmt.format(-Math.round(diffMin), 'minute');
  if (diffMin < 60 * 12) return relFmt.format(-Math.round(diffMin / 60), 'hour');
  return dateFmt.format(d);
}

/** Editing times: "75.5" -> "1:15.5" (tenths of a second). */
export function formatTime(seconds) {
  if (!isFinite(seconds)) return '';
  const tenths = Math.round(Math.max(0, seconds) * 10); // round first, so 59.96 s is 1:00.0, not 0:60.0
  const s = tenths / 10;
  const hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60);
  const sec = ((tenths % 600) / 10).toFixed(1).padStart(4, '0');
  return hh > 0 ? `${hh}:${String(mm).padStart(2, '0')}:${sec}` : `${mm}:${sec}`;
}

/** "1:15.5" / "75.5" / "0:01:15" -> seconds, or NaN. */
export function parseTime(text) {
  const parts = String(text ?? '').trim().split(':');
  if (!parts.length || parts.length > 3 || parts.some((p) => !/^\d+(\.\d*)?$/.test(p))) return NaN;
  return parts.reduce((total, p) => total * 60 + Number(p), 0);
}

/** Displays a shortcut like "Ctrl+Shift+G" as key caps. */
export function keycaps(spec) {
  if (!spec) return h('span', { class: 'muted' }, 'Not set');
  const wrap = h('span', { class: 'keys' });
  spec.split('+').forEach((k) => wrap.append(h('kbd', {}, k)));
  return wrap;
}

// ---------------------------------------------------------------- feedback

/** Shows a Fluent message bar as a toast. intent: info | success | warning | error */
export function toast(message, intent = 'info', timeout = 5000) {
  const bar = h('fluent-message-bar', { intent, layout: 'multiline', shape: 'rounded' },
    h('span', { slot: 'icon', class: 'icon' }),
    message,
    h('fluent-button', {
      slot: 'dismiss', appearance: 'transparent', 'icon-only': true, size: 'small', 'aria-label': 'Dismiss',
      onclick: () => bar.remove(),
    }, icon('dismiss_20_regular')));
  bar.querySelector('[slot=icon]').replaceWith(Object.assign(icon(
    intent === 'success' ? 'checkmark_circle_20_filled' : intent === 'error' ? 'error_circle_20_filled'
      : intent === 'warning' ? 'warning_20_filled' : 'info_20_filled'), { slot: 'icon' }));
  document.getElementById('toasts').append(bar);
  if (timeout) setTimeout(() => bar.remove(), timeout);
  return bar;
}

/**
 * The new state from a Fluent dialog's "toggle" event. Fluent v3 sends it as a custom event
 * (state in event.detail); the native dialog's own toggle event stays inside the component.
 */
export function dialogState(e) {
  return e.newState ?? e.detail?.newState;
}

/**
 * Confirmation dialog (Fluent dialog, type="alert"). Resolves true if confirmed.
 *   await confirmDialog({ title, text, ok: 'Delete', danger: true })
 */
export function confirmDialog({ title, text, ok = 'OK', danger = false }) {
  const dlg = document.getElementById('dlg-confirm');
  document.getElementById('dlg-confirm-title').textContent = title;
  document.getElementById('dlg-confirm-text').textContent = text;
  const okBtn = document.getElementById('dlg-confirm-ok');
  const cancelBtn = document.getElementById('dlg-confirm-cancel');
  okBtn.textContent = ok;
  okBtn.classList.toggle('danger', danger);
  return new Promise((resolve) => {
    let result = false;
    const done = () => {
      okBtn.removeEventListener('click', onOk);
      cancelBtn.removeEventListener('click', onCancel);
      dlg.removeEventListener('toggle', onToggle);
      resolve(result);
    };
    const onOk = () => { result = true; dlg.hide(); };
    const onCancel = () => dlg.hide();
    const onToggle = (e) => { if (dialogState(e) === 'closed') done(); };
    okBtn.addEventListener('click', onOk);
    cancelBtn.addEventListener('click', onCancel);
    dlg.addEventListener('toggle', onToggle);
    dlg.show();
    requestAnimationFrame(() => cancelBtn.focus());
  });
}

/** Builds a Windows-11-style settings row. */
export function settingRow({ iconName, label, desc, control, sub = false, id }) {
  const descEl = desc instanceof Node ? desc : h('span', { class: 'setting-desc' }, desc ?? '');
  if (!(desc instanceof Node)) descEl.className = 'setting-desc';
  const labelId = id ? `${id}-label` : undefined;
  return h('div', { class: `setting${sub ? ' sub' : ''}`, id },
    iconName ? icon(iconName) : h('span'),
    h('div', { class: 'setting-text' }, h('span', { class: 'setting-label', id: labelId }, label), desc ? descEl : null),
    h('div', { class: 'setting-control' }, control));
}
